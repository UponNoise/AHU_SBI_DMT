#,date,time,zip_code,latitude,longitude,contributing_factor_vehicle1,contributing_factor_vehicle2,vehicle_type_code_1,vehicle_type_code_2
1,2021-04-23,15:28:00,11221,40.68789,-73.936035,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
2,2021-12-16,00:23:00,11222,40.732822,-73.95205,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
3,2021-09-15,19:53:00,11233,40.67069,-73.91703,Cell Phone (hand-Held),Traffic Control Device Improper/Non-Working,Station Wagon/Sport Utility Vehicle,Sedan
4,2021-09-13,08:17:00,10028,40.773148,-73.950554,Cell Phone (hand-Held),Unspecified,Van,Station Wagon/Sport Utility Vehicle
5,2021-04-30,22:30:00,11377,40.74875,-73.90077,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
6,2021-09-18,10:00:00,,40.54396,-74.19184,Cell Phone (hand-Held),Unspecified,Motorbike,Sedan
7,2021-04-28,17:45:00,11226,40.650806,-73.94958,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
8,2021-12-06,20:15:00,,40.681767,-73.96754,Cell Phone (hands-free),Unspecified,Sedan,Moped
9,2022-06-29,16:18:00,,40.74942,-73.940544,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
10,2021-09-24,09:30:00,,40.77437,-73.963554,Failure to Yield Right-of-Way,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Sedan
11,2021-05-18,08:02:00,,40.720436,-74.00671,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
12,2021-05-20,03:19:00,10462,40.83362,-73.8571,Cell Phone (hand-Held),,Sedan,
13,2021-12-25,06:50:00,11361,40.75759,-73.78108,Cell Phone (hand-Held),Unspecified,E-Bike,Sedan
14,2022-06-26,11:50:00,,40.6674,-73.773636,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
15,2021-05-15,12:45:00,10027,40.808857,-73.96586,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,E-Bike
16,2021-05-28,15:22:00,,40.63083,-73.90736,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
17,2021-06-05,03:52:00,10019,40.761036,-73.98702,Cell Phone (hand-Held),Driver Inattention/Distraction,Sedan,Station Wagon/Sport Utility Vehicle
18,2021-10-04,11:20:00,,40.709023,-73.798195,Cell Phone (hands-free),Unspecified,Flat Bed,Sedan
19,2021-06-06,04:51:00,11216,40.682835,-73.94092,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
20,2021-06-11,16:00:00,10065,40.764786,-73.96844,Tinted Windows,Cell Phone (hands-free),Sedan,Pick-up Truck
21,2022-04-25,16:20:00,11413,40.672173,-73.761024,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
22,2021-05-22,21:10:00,,40.814487,-73.95547,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,E-Bike
23,2022-03-06,16:25:00,10014,40.730415,-74.00252,Other Vehicular,Cell Phone (hand-Held),Taxi,Bike
24,2022-01-07,03:08:00,,,,Cell Phone (hand-Held),Driver Inattention/Distraction,Station Wagon/Sport Utility Vehicle,Sedan
25,2021-06-30,04:45:00,10473,40.819878,-73.85777,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
26,2022-01-12,18:25:00,10455,40.818993,-73.909744,Other Vehicular,Cell Phone (hands-free),Sedan,
27,2022-01-15,02:35:00,,40.747925,-73.88114,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
28,2022-01-15,23:26:00,11362,40.768795,-73.73708,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
29,2021-07-18,11:35:00,10001,40.749325,-73.99638,Cell Phone (hand-Held),Failure to Yield Right-of-Way,Taxi,Station Wagon/Sport Utility Vehicle
30,2021-07-18,12:25:00,10035,40.80549,-73.937965,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
31,2021-10-31,05:30:00,10451,40.82054,-73.930786,Cell Phone (hand-Held),Unspecified,Sedan,Garbage or Refuse
32,2021-07-21,15:54:00,10456,40.829998,-73.90632,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
33,2021-07-21,22:36:00,10023,40.7736,-73.98158,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
34,2021-10-16,08:20:00,,40.7934492,-73.9328309,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
35,2022-04-12,18:00:00,11223,40.60636,-73.97532,Cell Phone (hand-Held),Unspecified,Sedan,Pick-up Truck
36,2021-08-04,18:59:00,,40.81438,-73.89623,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
37,2021-08-05,20:15:00,10452,40.841618,-73.912476,Cell Phone (hand-Held),,Moped,
38,2021-08-06,01:34:00,11429,40.714447,-73.73211,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
39,2022-04-14,16:02:00,11206,40.699707,-73.95718,Cell Phone (hand-Held),Unspecified,Bike,Station Wagon/Sport Utility Vehicle
40,2021-08-13,15:54:00,10457,40.837643,-73.90334,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
41,2021-08-12,22:40:00,11215,40.67146,-73.99103,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
42,2021-08-15,04:43:00,11222,40.725582,-73.94873,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
43,2022-04-14,09:15:00,,40.82309,-73.956345,Cell Phone (hands-free),Unspecified,Sedan,Sedan
44,2021-08-26,19:59:00,11418,40.69035,-73.84108,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
45,2022-01-28,02:00:00,10036,40.7608,-73.98844,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
46,2021-11-06,03:44:00,,40.762447,-73.91949,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
47,2021-08-30,18:00:00,11436,40.680088,-73.80177,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
48,2021-08-31,14:05:00,10467,40.865765,-73.86735,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
49,2022-01-26,08:00:00,,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
50,2021-09-09,01:05:00,11419,40.687153,-73.82462,Cell Phone (hand-Held),Turning Improperly,Sedan,Sedan
51,2021-08-23,11:02:00,10470,40.90304,-73.849556,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
52,2021-09-09,01:25:00,10467,40.873943,-73.87035,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
53,2021-11-15,15:10:00,10007,40.713657,-74.00152,Cell Phone (hand-Held),Unspecified,Sedan,Van
54,2021-11-16,22:10:00,,40.76332,-73.77385,Cell Phone (hand-Held),Unspecified,Convertible,Station Wagon/Sport Utility Vehicle
55,2022-04-18,16:35:00,,40.676304,-73.82029,Cell Phone (hand-Held),Passing or Lane Usage Improper,Station Wagon/Sport Utility Vehicle,PK
56,2022-02-08,18:50:00,11204,40.608078,-73.979706,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
57,2021-11-19,15:31:00,11434,40.66588,-73.80184,Cell Phone (hand-Held),Unspecified,Sedan,
58,2021-11-17,18:05:00,,40.680218,-73.775505,Cell Phone (hand-Held),,E-Bike,
59,2021-11-23,19:00:00,10309,40.526226,-74.22007,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
60,2021-09-29,02:35:00,,40.511734,-74.21044,Cell Phone (hand-Held),,Sedan,
61,2021-11-28,17:30:00,,40.766144,-73.99724,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
62,2021-11-30,02:22:00,,40.667164,-73.93407,Cell Phone (hands-free),Unspecified,Sedan,Sedan
63,2021-12-05,23:46:00,11215,40.666126,-73.9953,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
64,2021-12-14,17:42:00,,40.684494,-73.86169,Cell Phone (hand-Held),Unspecified,Sedan,Box Truck
65,2022-07-15,14:00:00,,40.55554,-74.17562,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
66,2023-08-04,06:23:00,11420,40.682003,-73.81606,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
67,2022-03-15,03:35:00,10025,40.805508,-73.96201,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
68,2022-07-14,11:00:00,10032,40.82968,-73.94185,Cell Phone (hand-Held),Unspecified,Sedan,
69,2022-03-20,13:37:00,11207,40.660778,-73.87938,Cell Phone (hand-Held),Unspecified,Sedan,
70,2022-05-08,02:34:00,11215,0,0,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
71,2022-05-12,09:15:00,11207,40.662395,-73.899216,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
72,2022-05-14,04:30:00,10304,40.608574,-74.087456,Cell Phone (hand-Held),,Sedan,
73,2022-10-01,04:00:00,,40.843254,-73.892136,Reaction to Uninvolved Vehicle,Cell Phone (hand-Held),Sedan,
74,2022-05-16,06:25:00,11236,40.65241,-73.90806,Other Vehicular,Cell Phone (hand-Held),Sedan,Concrete Mixer
75,2022-07-24,11:05:00,10036,40.75866,-73.98875,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
76,2022-05-22,00:42:00,11223,40.59376,-73.98274,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
77,2022-07-24,04:07:00,10309,40.542248,-74.21818,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
78,2023-08-03,17:23:00,11209,40.623272,-74.024536,Driver Inattention/Distraction,Cell Phone (hand-Held),Sedan,E-Bike
79,2023-01-17,06:54:00,,,,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
80,2022-06-01,16:20:00,11419,40.6854,-73.82947,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
81,2022-06-01,18:00:00,11236,40.645622,-73.904236,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
82,2022-08-04,08:20:00,10467,40.878357,-73.86409,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
83,2022-08-03,17:15:00,,40.809044,-73.92856,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
84,2022-06-18,21:15:00,11377,40.73568,-73.90471,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
85,2022-06-25,18:20:00,11228,40.6146,-74.00413,Cell Phone (hand-Held),,Bike,
86,2022-06-26,00:14:00,10469,40.87965,-73.84236,Cell Phone (hand-Held),Turning Improperly,Sedan,
87,2022-06-27,08:00:00,11420,40.666084,-73.82809,Cell Phone (hand-Held),Unspecified,Sedan,Motorcycle
88,2023-11-01,20:50:00,,40.70665,-73.95042,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
89,2022-08-20,07:50:00,10462,40.84634,-73.86655,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
90,2023-05-02,07:24:00,,40.870907,-73.90725,Cell Phone (hands-free),Unspecified,Taxi,Station Wagon/Sport Utility Vehicle
91,2022-08-26,15:00:00,10453,40.85038,-73.90699,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
92,2022-10-21,22:45:00,,40.772697,-73.83396,Cell Phone (hands-free),Unspecified,Motorcycle,Sedan
93,2023-05-01,14:09:00,,40.724236,-73.997795,Cell Phone (hands-free),Unspecified,Taxi,Bike
94,2022-10-23,13:12:00,,,,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
95,2022-09-03,21:20:00,,40.698463,-73.960205,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
96,2022-09-02,12:35:00,10451,40.814816,-73.925705,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Station Wagon/Sport Utility Vehicle
97,2023-02-03,11:35:00,,40.7065,-73.91701,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
98,2022-09-08,08:30:00,11211,40.711674,-73.95383,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
99,2022-09-10,20:00:00,,40.729084,-73.93104,Cell Phone (hand-Held),Unspecified,Sedan,Trailor
100,2022-10-27,16:04:00,11219,40.626823,-73.996796,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
101,2022-10-29,02:25:00,11236,40.63258,-73.88831,Cell Phone (hand-Held),Alcohol Involvement,Sedan,Sedan
102,2022-09-15,16:40:00,11207,40.65906,-73.88459,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,
103,2023-08-07,14:35:00,11378,40.722218,-73.90132,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
104,2022-11-03,00:46:00,11219,40.636806,-73.99204,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
105,2022-11-06,19:42:00,11220,40.63778,-74.01794,Driver Inattention/Distraction,Cell Phone (hand-Held),Sedan,Station Wagon/Sport Utility Vehicle
106,2022-11-12,18:47:00,11106,40.76034,-73.936386,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
107,2023-11-05,03:20:00,11204,40.6102,-73.99072,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
108,2023-02-18,07:25:00,11101,40.745903,-73.92955,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
109,2022-11-23,14:02:00,10451,40.826836,-73.92263,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
110,2023-05-10,06:13:00,11234,40.609715,-73.93261,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
111,2023-08-11,12:54:00,11236,40.6481,-73.91474,Driver Inexperience,Cell Phone (hand-Held),Sedan,Sedan
112,2023-05-02,07:55:00,11691,40.600567,-73.7621,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
113,2024-02-01,01:35:00,11203,40.64664,-73.9246,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
114,2022-12-14,06:45:00,10314,40.612972,-74.12417,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
115,2022-12-21,21:11:00,10027,40.81286,-73.96341,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
116,2023-08-13,14:50:00,,40.704636,-73.94104,Cell Phone (hand-Held),Unspecified,Motorcycle,Sedan
117,2024-02-02,15:47:00,10467,40.87703,-73.86536,Driver Inattention/Distraction,Cell Phone (hand-Held),Sedan,Pick-up Truck
118,2023-01-11,15:20:00,11207,40.6828,-73.90638,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
119,2023-05-25,18:50:00,10022,40.758114,-73.9754,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Pedicab
120,2023-03-24,13:30:00,11103,40.76712,-73.9099,Cell Phone (hand-Held),Driver Inattention/Distraction,Sedan,Station Wagon/Sport Utility Vehicle
121,2023-08-12,22:02:00,,40.733498,-73.87038,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
122,2023-03-26,06:22:00,,40.82797,-73.83391,Cell Phone (hand-Held),,Sedan,
123,2023-05-29,12:40:00,11422,40.663223,-73.73351,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
124,2023-04-01,18:26:00,11377,40.743214,-73.907166,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
125,2023-04-09,17:22:00,11413,40.66743,-73.74474,Cell Phone (hand-Held),,,
126,2023-04-11,09:27:00,11212,40.660873,-73.90947,Driver Inexperience,Cell Phone (hand-Held),Sedan,Station Wagon/Sport Utility Vehicle
127,2023-08-21,10:55:00,10474,40.818604,-73.88917,Cell Phone (hand-Held),Unspecified,Sedan,E-Bike
128,2023-04-15,23:44:00,,40.54643,-74.20989,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
129,2023-11-12,12:20:00,11210,40.619606,-73.945526,Failure to Yield Right-of-Way,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Bike
130,2023-06-09,07:24:00,,,,Cell Phone (hand-Held),,Sedan,
131,2023-08-27,07:40:00,11207,40.66937,-73.89523,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
132,2024-02-06,15:53:00,11219,40.637684,-73.98934,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
133,2023-06-17,09:33:00,,40.817844,-73.94185,Cell Phone (hand-Held),Unspecified,Sedan,Bike
134,2023-08-20,13:25:00,11106,40.757313,-73.92915,Passing or Lane Usage Improper,Cell Phone (hand-Held),Sedan,
135,2023-06-20,21:46:00,,40.7516,-73.74844,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
136,2023-08-28,05:22:00,11213,40.671032,-73.93927,Cell Phone (hand-Held),Unspecified,Sedan,USPS TRUCK
137,2024-04-08,01:45:00,,40.81766,-73.93076,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
138,2023-07-09,16:42:00,11236,40.6411,-73.90463,Cell Phone (hand-Held),Driver Inexperience,Sedan,Motorcycle
139,2023-09-11,03:09:00,10002,40.720707,-73.981316,Cell Phone (hand-Held),,Sedan,
140,2023-07-12,21:39:00,11106,40.761356,-73.935394,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,E-Bike
141,2024-02-11,01:17:00,,40.742985,-73.79268,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
142,2024-02-11,07:05:00,10301,40.641598,-74.08318,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
143,2023-07-22,04:20:00,10304,40.597633,-74.09262,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
144,2023-07-22,12:50:00,10305,40.592342,-74.064186,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
145,2023-09-18,20:15:00,11226,40.64193,-73.95841,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
146,2023-11-24,23:29:00,11377,40.759483,-73.904564,Cell Phone (hand-Held),,Sedan,
147,2023-07-31,13:28:00,,40.610508,-74.09576,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
148,2023-09-25,23:40:00,11379,40.718903,-73.86878,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
149,2023-09-28,10:08:00,,40.764297,-73.90304,Cell Phone (hand-Held),Unspecified,Pick up,Pick-up Truck
150,2023-11-30,18:54:00,11377,40.753643,-73.90767,Traffic Control Disregarded,Cell Phone (hands-free),Sedan,Motorcycle
151,2023-10-16,09:45:00,,,,Unsafe Lane Changing,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
152,2024-02-17,06:30:00,10016,40.74084,-73.97631,Cell Phone (hand-Held),View Obstructed/Limited,Sedan,Sedan
153,2023-12-08,21:30:00,11004,40.752037,-73.71898,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
154,2023-10-19,18:30:00,11236,40.63747,-73.91027,Cell Phone (hand-Held),Unspecified,Sedan,Bike
155,2024-05-06,19:42:00,10456,40.830257,-73.914856,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
156,2024-05-09,16:25:00,,40.72522,-73.894745,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
157,2023-12-16,15:23:00,,,,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
158,2023-12-19,01:40:00,,40.605427,-74.0762,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
159,2024-02-29,18:30:00,10468,40.880688,-73.885704,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
160,2024-03-02,06:40:00,,40.60181,-74.09283,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
161,2023-12-31,17:35:00,10308,40.542427,-74.14591,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Taxi
162,2024-01-01,06:25:00,,40.748848,-73.872375,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
163,2024-03-04,23:55:00,11436,40.670322,-73.79428,Cell Phone (hands-free),Unspecified,Sedan,Sedan
164,2024-01-03,08:24:00,11236,40.642673,-73.90869,Turning Improperly,Cell Phone (hand-Held),Sedan,Station Wagon/Sport Utility Vehicle
165,2024-03-05,18:40:00,,40.68039,-73.94956,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Moped
166,2024-05-14,19:59:00,,40.867733,-73.88285,Cell Phone (hand-Held),Unspecified,Sedan,E-Bike
167,2024-01-10,18:15:00,11207,40.660408,-73.892006,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
168,2024-05-19,00:00:00,10459,40.822285,-73.89174,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
169,2024-01-18,15:55:00,11417,40.676003,-73.84351,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
170,2024-01-17,15:08:00,11366,40.725555,-73.79253,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
171,2024-03-19,06:14:00,,40.844173,-73.8997,View Obstructed/Limited,Cell Phone (hand-Held),Tractor Truck Diesel,Station Wagon/Sport Utility Vehicle
172,2024-05-25,12:50:00,,40.831776,-73.82097,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
173,2024-03-29,15:33:00,10304,40.596443,-74.092964,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
174,2024-03-23,11:00:00,,40.666706,-73.871826,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
175,2024-04-01,17:14:00,10309,40.5444,-74.228584,Cell Phone (hand-Held),Other Vehicular,Sedan,forklift
176,2024-04-06,07:20:00,11225,40.66408,-73.94817,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
177,2024-06-01,18:10:00,11207,40.6559,-73.87897,Cell Phone (hand-Held),Unspecified,Sedan,Van
178,2024-04-07,12:31:00,11369,40.761147,-73.87691,Cell Phone (hand-Held),Unspecified,Convertible,Sedan
179,2024-04-11,03:45:00,11236,40.64503,-73.91998,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
180,2024-04-17,08:10:00,11428,40.719585,-73.733154,Cell Phone (hand-Held),Unspecified,E-Scooter,Sedan
181,2024-04-18,00:45:00,10036,40.757133,-73.98745,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
182,2024-06-20,14:00:00,11429,40.713493,-73.736496,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
183,2024-06-30,07:32:00,10465,40.82928,-73.81702,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
184,2024-07-02,14:00:00,10001,40.748985,-73.993706,Cell Phone (hand-Held),Unspecified,Sedan,Bike
185,2024-07-03,22:48:00,11205,40.698048,-73.97579,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
186,2024-06-29,22:10:00,10461,40.857414,-73.84662,Cell Phone (hand-Held),Unspecified,Sedan,Moped
187,2024-07-13,07:28:00,,40.725727,-73.90037,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
188,2017-11-22,04:17:00,10456,40.834507,-73.91772,Cell Phone (hand-Held),Unspecified,Taxi,Taxi
189,2021-02-28,20:40:00,10033,40.846977,-73.93625,Cell Phone (hand-Held),Unspecified,Sedan,
190,2021-04-03,05:00:00,11232,40.651264,-74.003914,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
191,2021-04-03,20:36:00,,40.8347,-73.91827,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
192,2021-03-02,00:05:00,10451,40.826607,-73.926636,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
193,2021-04-08,00:46:00,,40.743164,-73.77733,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
194,2021-04-10,17:55:00,,40.667114,-73.834656,Cell Phone (hand-Held),Unspecified,Chassis Cab,Sedan
195,2021-02-27,20:58:00,,40.856537,-73.87257,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
196,2021-02-28,03:10:00,11378,40.729847,-73.88909,Cell Phone (hand-Held),,E-Bike,
197,2021-04-05,16:52:00,11225,40.667744,-73.95902,Driver Inattention/Distraction,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Bike
198,2021-03-22,09:29:00,11228,40.61334,-74.01109,Cell Phone (hand-Held),Unspecified,Box Truck,Station Wagon/Sport Utility Vehicle
199,2021-04-01,22:29:00,,40.72592,-73.72439,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
200,2021-02-16,20:00:00,10032,40.842915,-73.9366,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
201,2021-03-18,04:18:00,10467,40.873234,-73.86299,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
202,2021-01-17,04:00:00,,40.673008,-73.87038,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
203,2020-12-31,18:45:00,11102,40.771133,-73.92683,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
204,2021-01-16,00:24:00,10457,40.837654,-73.89997,Driver Inattention/Distraction,Cell Phone (hand-Held),Taxi,Sedan
205,2021-01-29,02:18:00,10467,40.86536,-73.87043,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
206,2020-11-09,23:38:00,,40.701267,-73.98772,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
207,2020-11-09,00:40:00,11103,40.761475,-73.915855,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
208,2020-11-08,01:20:00,,40.602028,-74.18777,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
209,2020-11-11,22:15:00,10013,40.719395,-74.00189,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
210,2020-12-02,17:12:00,,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
211,2020-11-09,17:30:00,10012,40.725773,-74.00091,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
212,2020-12-05,04:00:00,,40.755566,-73.79172,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
213,2020-11-21,08:18:00,11210,40.63477,-73.94496,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
214,2020-11-17,14:45:00,,40.78843,-73.94907,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
215,2020-12-02,14:30:00,,40.61709,-73.91895,Cell Phone (hand-Held),,Bike,
216,2020-09-22,12:34:00,11208,40.689133,-73.87441,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Box Truck
217,2020-09-18,17:56:00,11209,40.619537,-74.03266,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
218,2020-09-04,01:12:00,,40.845467,-73.92813,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
219,2020-09-09,00:00:00,,40.679276,-73.92906,Driver Inattention/Distraction,Cell Phone (hand-Held),Sedan,E-Bike
220,2020-08-23,01:52:00,11427,40.73024,-73.75327,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Station Wagon/Sport Utility Vehicle
221,2020-10-05,00:41:00,,40.826523,-73.93116,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
222,2020-09-29,14:30:00,11238,40.67766,-73.968864,Cell Phone (hand-Held),Unspecified,Bike,Station Wagon/Sport Utility Vehicle
223,2020-09-03,12:24:00,11385,40.69397,-73.89823,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
224,2020-09-04,20:40:00,10002,40.719933,-73.97876,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
225,2020-08-23,02:18:00,10029,40.792812,-73.937744,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
226,2020-09-24,14:50:00,10304,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
227,2020-10-04,12:32:00,,40.692463,-73.81082,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
228,2020-08-15,17:30:00,10457,40.84921,-73.90011,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
229,2020-07-30,07:00:00,11221,40.694138,-73.92649,Cell Phone (hand-Held),Unspecified,Box Truck,Station Wagon/Sport Utility Vehicle
230,2020-07-09,20:18:00,10456,40.830914,-73.92047,Traffic Control Disregarded,Cell Phone (hand-Held),moped,Sedan
231,2020-08-20,16:07:00,11362,40.763317,-73.7442,Cell Phone (hands-free),Unspecified,Sedan,Sedan
232,2020-08-09,12:24:00,11412,40.691032,-73.76231,Cell Phone (hand-Held),Unspecified,Sedan,
233,2020-08-03,14:04:00,10002,40.718006,-73.9866,Cell Phone (hands-free),Unspecified,Sedan,Sedan
234,2020-07-24,03:40:00,11357,40.77831,-73.82149,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
235,2020-04-15,19:30:00,,40.763416,-73.92844,Failure to Yield Right-of-Way,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Bike
236,2020-05-12,19:15:00,11236,40.6338,-73.8897,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
237,2020-05-03,23:42:00,11203,40.649277,-73.94361,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
238,2020-06-13,18:30:00,,40.830914,-73.92047,Following Too Closely,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
239,2020-04-24,16:17:00,10009,40.723076,-73.97649,Cell Phone (hands-free),,Van,
240,2020-05-21,07:33:00,10026,40.80167,-73.95096,Driver Inattention/Distraction,Cell Phone (hand-Held),Sedan,Bike
241,2020-05-10,17:05:00,10459,40.83078,-73.88954,Cell Phone (hand-Held),Unspecified,Taxi,E-Bike
242,2020-04-29,21:30:00,10304,40.59102,-74.100914,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Sedan
243,2020-04-13,00:10:00,11213,40.676743,-73.93316,Following Too Closely,Cell Phone (hand-Held),Sedan,Station Wagon/Sport Utility Vehicle
244,2020-06-07,00:50:00,11231,40.67828,-74.014,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
245,2020-04-20,13:00:00,11433,40.707893,-73.78675,Cell Phone (hand-Held),,Sedan,
246,2020-06-22,08:20:00,,,,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
247,2020-03-11,13:10:00,,40.74045,-73.844376,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
248,2020-03-01,17:30:00,11231,40.6828,-74.00005,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Bike
249,2020-03-06,08:15:00,10030,40.822834,-73.941925,Cell Phone (hand-Held),Unspecified,Taxi,Taxi
250,2020-03-21,00:35:00,10459,40.825283,-73.88648,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
251,2020-03-10,12:32:00,11220,40.640625,-74.014984,Driver Inattention/Distraction,Cell Phone (hand-Held),Taxi,Station Wagon/Sport Utility Vehicle
252,2020-02-20,21:25:00,,40.731777,-73.77011,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
253,2020-02-25,13:47:00,,40.667652,-73.88531,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
254,2020-03-06,01:45:00,11204,40.620323,-73.990524,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
255,2020-02-21,12:50:00,,40.844883,-73.907295,Cell Phone (hand-Held),Unspecified,Sedan,
256,2020-02-16,16:08:00,,40.80939,-73.88042,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
257,2020-01-31,18:37:00,11358,40.75115,-73.78955,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
258,2020-01-29,13:30:00,,40.729877,-73.98966,Pedestrian/Bicyclist/Other Pedestrian Error/Confusion,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Bike
259,2020-02-08,19:23:00,11373,40.733448,-73.870056,Cell Phone (hands-free),Unspecified,Sedan,Sedan
260,2020-02-09,16:11:00,10455,40.818954,-73.91404,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
261,2020-02-01,03:17:00,10473,40.82138,-73.86298,Cell Phone (hand-Held),,Bike,
262,2020-02-02,02:05:00,11220,40.640057,-74.028,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
263,2020-02-15,15:10:00,,,,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
264,2020-01-14,06:40:00,10462,40.840267,-73.862526,Cell Phone (hand-Held),,Sedan,
265,2019-12-30,22:20:00,,40.713444,-73.99854,Cell Phone (hands-free),,Sedan,
266,2019-12-19,13:52:00,,40.8317,-73.935394,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
267,2020-01-10,15:50:00,,40.80543,-73.92087,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
268,2019-12-12,07:45:00,,40.689964,-73.796776,Cell Phone (hand-Held),Passing or Lane Usage Improper,Sedan,Station Wagon/Sport Utility Vehicle
269,2019-12-12,10:16:00,11205,40.696133,-73.95647,Other Vehicular,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Sedan
270,2019-11-23,10:30:00,,40.89675,-73.85988,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
271,2019-11-27,14:39:00,10457,40.846687,-73.905594,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
272,2019-11-21,22:00:00,11225,40.662106,-73.95467,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
273,2019-10-25,22:20:00,,40.56042,-74.1595,Cell Phone (hand-Held),Unspecified,2 dr sedan,Sedan
274,2019-10-23,10:45:00,,40.82499,-73.91662,Pedestrian/Bicyclist/Other Pedestrian Error/Confusion,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Bike
275,2019-10-19,13:10:00,11228,40.609474,-74.01089,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,
276,2019-10-18,13:29:00,,40.756485,-73.94005,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
277,2019-11-09,04:15:00,,40.737152,-73.90602,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
278,2019-11-01,21:00:00,11355,40.757008,-73.83025,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Bike
279,2019-09-27,09:30:00,,,,Cell Phone (hands-free),Unsafe Lane Changing,Van,Van
280,2019-09-23,13:45:00,,40.851093,-73.93244,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
281,2019-10-13,01:17:00,10457,40.838875,-73.90266,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
282,2019-10-04,08:30:00,,40.767372,-73.950066,Following Too Closely,Cell Phone (hands-free),Sedan,Station Wagon/Sport Utility Vehicle
283,2019-10-10,11:15:00,,40.754105,-73.72321,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
284,2019-09-21,07:10:00,10032,40.833687,-73.94012,Cell Phone (hands-free),Unspecified,Sedan,Sedan
285,2019-09-16,11:08:00,,40.745842,-73.73009,Cell Phone (hands-free),Unspecified,Sedan,Sedan
286,2019-09-07,20:41:00,,40.75332,-73.9636,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
287,2019-08-23,14:30:00,10469,40.879997,-73.84834,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
288,2019-09-12,06:20:00,11354,40.769493,-73.844315,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
289,2019-08-29,15:40:00,10065,40.76484,-73.970505,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
290,2019-09-13,23:00:00,11358,40.76543,-73.8033,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
291,2019-09-04,19:20:00,,,,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
292,2019-08-17,16:10:00,,40.678394,-73.94692,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
293,2019-07-27,22:30:00,11357,40.7947,-73.80691,Cell Phone (hand-Held),Unspecified,Sedan,Pick-up Truck
294,2019-08-08,18:48:00,,40.865143,-73.87204,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
295,2019-08-10,23:53:00,,40.69302,-73.93706,Cell Phone (hand-Held),Passing or Lane Usage Improper,Sedan,Sedan
296,2019-08-13,17:30:00,,40.838062,-73.94794,Cell Phone (hands-free),Driver Inattention/Distraction,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
297,2019-08-07,19:50:00,,40.773964,-73.9228,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
298,2019-07-13,22:30:00,,40.796,-73.93542,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
299,2019-07-12,11:30:00,,40.62756,-74.041275,Cell Phone (hand-Held),Other Vehicular,Sedan,Sedan
300,2019-07-05,00:00:00,,40.62432,-74.15594,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
301,2019-07-12,22:00:00,10454,40.809776,-73.92241,Cell Phone (hand-Held),Unspecified,Sedan,Pick-up Truck
302,2019-07-02,10:30:00,10036,40.756035,-73.98695,Cell Phone (hand-Held),Unspecified,Taxi,Bike
303,2019-07-15,14:20:00,10472,40.831245,-73.86197,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Station Wagon/Sport Utility Vehicle
304,2019-06-30,18:50:00,,40.603485,-73.76859,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
305,2019-07-12,18:00:00,11234,40.61957,-73.93355,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
306,2019-07-06,03:40:00,10469,40.86986,-73.8546,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
307,2019-06-23,23:41:00,11220,40.6402,-74.00825,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Motorcycle
308,2019-06-22,00:00:00,,40.695004,-73.9525,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
309,2019-06-24,18:00:00,,40.724495,-73.72469,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
310,2019-04-06,17:50:00,,40.862812,-73.907555,Cell Phone (hand-Held),Unspecified,Sedan,
311,2019-06-18,18:10:00,11385,40.70456,-73.856735,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
312,2019-05-31,20:30:00,,40.67052,-73.99798,Cell Phone (hands-free),Following Too Closely,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
313,2019-06-15,20:15:00,,40.694416,-73.83599,Cell Phone (hands-free),Unspecified,Bus,Station Wagon/Sport Utility Vehicle
314,2019-06-09,22:10:00,11432,40.708317,-73.78812,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
315,2019-06-11,20:51:00,11368,40.743725,-73.85627,Passing or Lane Usage Improper,Cell Phone (hand-Held),Sedan,Sedan
316,2019-06-15,04:40:00,,40.69691,-73.85745,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
317,2019-05-25,11:39:00,10035,40.80765,-73.939255,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,ELECT
318,2019-05-23,01:09:00,10462,40.84169,-73.86012,Cell Phone (hand-Held),Unspecified,Taxi,Sedan
319,2019-05-04,16:01:00,10452,40.83511,-73.91945,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
320,2019-05-17,01:51:00,,40.723022,-73.99882,Cell Phone (hands-free),Unspecified,Taxi,Station Wagon/Sport Utility Vehicle
321,2019-05-09,17:00:00,11375,40.724308,-73.842575,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
322,2019-05-24,15:19:00,11204,40.632717,-73.98377,Passing Too Closely,Cell Phone (hand-Held),Bus,Station Wagon/Sport Utility Vehicle
323,2019-05-08,17:50:00,11426,40.724037,-73.72568,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
324,2019-05-06,08:16:00,10016,40.74544,-73.9754,Following Too Closely,Cell Phone (hands-free),Station Wagon/Sport Utility Vehicle,Box Truck
325,2019-04-27,15:26:00,10459,40.8308,-73.88498,Cell Phone (hand-Held),Unspecified,Sedan,Bike
326,2019-04-16,17:05:00,10451,40.81429,-73.923676,Driver Inattention/Distraction,Cell Phone (hands-free),Sedan,Bike
327,2019-04-29,10:50:00,11694,40.582283,-73.82094,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
328,2019-04-16,20:25:00,11207,40.67657,-73.9008,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
329,2019-04-01,19:00:00,,40.74915,-73.98828,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
330,2019-03-31,11:10:00,,40.634815,-73.98876,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
331,2019-03-15,16:45:00,11201,40.691227,-73.98214,Cell Phone (hand-Held),View Obstructed/Limited,Bike,Station Wagon/Sport Utility Vehicle
332,2019-03-26,01:40:00,11428,40.719036,-73.74424,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
333,2019-03-24,19:16:00,10457,40.84442,-73.8984,Cell Phone (hand-Held),Unspecified,Sedan,
334,2019-02-10,14:30:00,11379,40.715805,-73.887924,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
335,2019-02-17,02:00:00,11222,40.726147,-73.94458,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
336,2019-02-15,09:35:00,11226,40.650806,-73.94958,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
337,2019-02-04,14:25:00,10010,40.739864,-73.989586,Unsafe Lane Changing,Cell Phone (hand-Held),Sedan,Taxi
338,2019-01-15,12:15:00,11217,40.687378,-73.98598,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
339,2019-01-23,12:31:00,10463,40.874615,-73.90472,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Sedan
340,2019-01-31,02:08:00,11203,40.64323,-73.92467,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
341,2019-01-07,18:30:00,11234,40.63774,-73.926125,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
342,2019-01-19,00:52:00,,40.60242,-73.99459,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
343,2019-01-11,15:45:00,,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
344,2019-01-16,09:45:00,10457,40.842987,-73.900345,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
345,2019-01-28,13:09:00,11354,40.767303,-73.83293,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
346,2019-01-27,15:00:00,,,,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
347,2019-01-03,14:20:00,,40.83717,-73.948906,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
348,2018-12-18,18:10:00,11225,40.65676,-73.960144,Failure to Yield Right-of-Way,Cell Phone (hand-Held),Sedan,Box Truck
349,2018-12-11,23:40:00,,40.735764,-73.97491,Cell Phone (hand-Held),Unspecified,TRAIL,Station Wagon/Sport Utility Vehicle
350,2018-12-15,14:45:00,,40.742657,-73.846214,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
351,2018-12-19,23:00:00,,,,Cell Phone (hands-free),Unspecified,Sedan,Sedan
352,2018-12-14,01:50:00,11101,40.74198,-73.94643,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
353,2018-12-24,01:20:00,10472,40.827618,-73.86685,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
354,2018-12-27,19:30:00,,40.640503,-73.95564,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
355,2018-12-15,12:40:00,,40.681473,-73.72776,Cell Phone (hand-Held),Unspecified,Taxi,Pick-up Truck
356,2018-11-14,12:25:00,,40.82419,-73.91385,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
357,2018-11-12,00:58:00,,40.74285,-73.830284,Cell Phone (hand-Held),,Sedan,
358,2018-12-04,08:00:00,,40.875122,-73.905174,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
359,2018-11-21,18:10:00,,40.848938,-73.93708,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
360,2018-11-20,09:47:00,11219,40.636562,-73.985634,Failure to Yield Right-of-Way,Cell Phone (hand-Held),Sedan,Sedan
361,2018-11-13,11:30:00,,40.75548,-73.74173,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
362,2018-11-16,13:00:00,10305,40.59589,-74.085884,Following Too Closely,Cell Phone (hand-Held),Sedan,Sedan
363,2018-11-09,19:20:00,10003,40.735573,-73.98488,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Bike
364,2018-10-25,10:20:00,11221,40.696396,-73.91412,Cell Phone (hand-Held),Other Vehicular,Sedan,Sedan
365,2018-10-30,10:15:00,,40.726376,-73.76624,Cell Phone (hands-free),Unspecified,Sedan,Sedan
366,2018-10-21,03:51:00,10472,40.827274,-73.8694,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
367,2018-10-28,15:30:00,,40.736073,-73.77356,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
368,2018-10-22,11:45:00,11432,40.71404,-73.78281,Cell Phone (hand-Held),Unspecified,Sedan,
369,2018-09-25,16:00:00,,40.88271,-73.881256,Cell Phone (hand-Held),Passing or Lane Usage Improper,Station Wagon/Sport Utility Vehicle,Sedan
370,2018-10-14,21:51:00,11368,40.75448,-73.865036,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
371,2018-10-08,17:05:00,,40.736004,-73.99362,Cell Phone (hand-Held),Unspecified,Sedan,Bike
372,2018-10-05,14:00:00,11226,40.646645,-73.95547,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
373,2018-10-04,08:32:00,,,,Cell Phone (hand-Held),Unspecified,Taxi,Station Wagon/Sport Utility Vehicle
374,2018-09-30,20:00:00,,40.722095,-73.77772,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
375,2018-10-04,15:05:00,10014,40.73939,-74.00762,Cell Phone (hand-Held),Unspecified,Sedan,Bike
376,2018-10-05,13:30:00,,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
377,2018-09-26,09:39:00,,40.834213,-73.82613,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
378,2018-10-06,04:40:00,10466,40.893623,-73.85525,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
379,2018-10-05,22:20:00,,40.790997,-73.94931,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
380,2018-10-07,14:30:00,,40.66732,-73.777275,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
381,2018-09-16,15:35:00,,,,Cell Phone (hand-Held),Following Too Closely,Sedan,Sedan
382,2018-09-01,19:05:00,11206,40.69725,-73.95244,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
383,2018-09-18,15:40:00,10462,40.85324,-73.86774,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
384,2018-09-19,08:20:00,,40.636833,-74.138214,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
385,2018-09-11,15:45:00,11101,40.7431,-73.95608,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
386,2018-09-20,23:10:00,,40.763508,-73.77193,Cell Phone (hand-Held),Failure to Yield Right-of-Way,Taxi,Sedan
387,2018-08-30,15:35:00,,40.681423,-74.00562,Following Too Closely,Cell Phone (hand-Held),Sedan,Sedan
388,2018-09-14,09:10:00,,40.852066,-73.868614,Cell Phone (hand-Held),Unspecified,Box Truck,Station Wagon/Sport Utility Vehicle
389,2018-08-12,12:40:00,10451,40.826855,-73.922676,Driver Inattention/Distraction,Cell Phone (hand-Held),Sedan,Carry All
390,2018-08-09,08:14:00,11369,40.75987,-73.86229,Cell Phone (hand-Held),Failure to Yield Right-of-Way,Sedan,Sedan
391,2018-08-03,19:00:00,,40.609432,-73.75479,Cell Phone (hand-Held),Unspecified,Bike,Sedan
392,2018-08-24,00:40:00,10461,40.842384,-73.846436,Cell Phone (hand-Held),Driver Inattention/Distraction,Sedan,Sedan
393,2018-08-03,08:05:00,,40.848793,-73.91495,Cell Phone (hand-Held),,Bus,
394,2018-08-03,19:00:00,,40.609432,-73.75479,Cell Phone (hand-Held),Unspecified,Sedan,Bike
395,2018-08-10,00:37:00,10012,40.727642,-73.999306,Driver Inattention/Distraction,Cell Phone (hands-free),Bike,
396,2018-08-27,05:00:00,11237,40.70377,-73.93116,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
397,2018-08-21,10:10:00,,40.828,-73.84701,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
398,2018-08-20,15:16:00,11236,40.64891,-73.89256,Cell Phone (hands-free),Unspecified,Sedan,Sedan
399,2018-07-10,19:51:00,10017,40.749825,-73.972206,Cell Phone (hand-Held),Turning Improperly,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
400,2018-07-29,04:31:00,10036,40.76213,-73.99548,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
401,2018-07-12,23:30:00,11225,40.663124,-73.96244,Cell Phone (hand-Held),Other Vehicular,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
402,2018-07-20,11:10:00,10019,40.76552,-73.98004,Cell Phone (hands-free),,,
403,2018-07-09,23:50:00,11434,40.667522,-73.78063,Cell Phone (hand-Held),Unspecified,Sedan,Bulk Agriculture
404,2018-07-23,13:20:00,11208,40.68628,-73.88028,Cell Phone (hand-Held),Unspecified,Bike,Station Wagon/Sport Utility Vehicle
405,2018-07-28,04:16:00,10469,40.875458,-73.85485,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
406,2018-07-16,09:20:00,10461,40.846848,-73.832504,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
407,2018-07-12,15:55:00,,40.800983,-73.92927,Cell Phone (hands-free),Unspecified,Sedan,Sedan
408,2018-07-08,16:21:00,11230,40.62418,-73.97048,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Bus
409,2018-07-08,09:30:00,10472,40.82923,-73.87551,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
410,2018-07-08,12:40:00,10462,40.838024,-73.848495,Cell Phone (hand-Held),Unspecified,Sedan,
411,2018-07-04,04:00:00,10017,40.753624,-73.96944,Cell Phone (hand-Held),Unspecified,Taxi,Sedan
412,2018-06-24,06:14:00,,40.69764,-73.92932,Cell Phone (hand-Held),Unspecified,Bike,Bus
413,2018-06-27,17:23:00,11434,40.66684,-73.78941,Driver Inattention/Distraction,Cell Phone (hand-Held),Sedan,Station Wagon/Sport Utility Vehicle
414,2018-06-16,15:30:00,11228,40.602814,-74.01453,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
415,2018-06-13,03:40:00,10301,40.6444,-74.087006,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
416,2018-06-16,03:01:00,10452,40.831333,-73.92167,Cell Phone (hand-Held),Following Too Closely,Sedan,Sedan
417,2018-07-05,23:00:00,11434,40.65616,-73.76736,Other Vehicular,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Sedan
418,2018-06-09,20:40:00,10307,40.512028,-74.24976,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
419,2018-05-22,07:00:00,,40.62368,-73.99772,Cell Phone (hands-free),Unspecified,Taxi,Carry All
420,2018-05-23,09:01:00,10462,40.844357,-73.86582,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
421,2018-05-27,00:01:00,10473,40.814415,-73.85012,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
422,2018-05-26,14:22:00,,40.604282,-73.97305,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
423,2018-06-02,17:05:00,,40.850098,-73.84498,Other Vehicular,Cell Phone (hand-Held),Sedan,
424,2018-06-08,12:10:00,10458,40.86723,-73.88692,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
425,2018-05-30,16:40:00,,40.60744,-74.16041,Cell Phone (hand-Held),Driver Inattention/Distraction,Pick-up Truck,Sedan
426,2018-06-08,21:04:00,,,,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
427,2018-06-04,13:35:00,,40.825165,-73.86699,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
428,2018-06-02,08:12:00,11101,40.747166,-73.942245,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Station Wagon/Sport Utility Vehicle
429,2018-04-24,04:30:00,11211,40.716778,-73.93635,Cell Phone (hand-Held),Following Too Closely,Sedan,Station Wagon/Sport Utility Vehicle
430,2018-05-05,12:25:00,,40.767242,-73.986206,Cell Phone (hands-free),Unspecified,Taxi,Taxi
431,2018-05-14,14:45:00,11205,40.690216,-73.96028,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
432,2018-05-03,16:20:00,,40.65008,-73.96101,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
433,2018-04-26,11:03:00,11203,40.649277,-73.94361,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
434,2018-04-29,00:30:00,11412,40.70439,-73.76063,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
435,2018-05-05,13:27:00,10025,40.79799,-73.96199,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
436,2018-04-29,04:50:00,10019,40.76132,-73.97995,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
437,2018-04-12,17:15:00,10029,40.796,-73.93542,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
438,2018-04-06,14:00:00,10037,40.808224,-73.93673,Cell Phone (hands-free),Unspecified,Sedan,Sedan
439,2018-04-03,14:20:00,,,,Cell Phone (hand-Held),Unsafe Speed,Sedan,Sedan
440,2018-04-19,00:01:00,11216,40.670006,-73.95328,Unsafe Lane Changing,Cell Phone (hand-Held),Sedan,Station Wagon/Sport Utility Vehicle
441,2018-03-27,14:44:00,,40.735764,-73.97491,Unsafe Lane Changing,Cell Phone (hand-Held),Sedan,Pick-up Truck
442,2018-04-17,17:24:00,,40.824158,-73.87462,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
443,2018-04-08,18:50:00,11218,,,Cell Phone (hands-free),Unspecified,Sedan,Sedan
444,2018-04-10,19:27:00,10024,40.784992,-73.98261,Cell Phone (hand-Held),,Sedan,
445,2018-03-31,00:00:00,11420,40.677654,-73.82866,Driver Inattention/Distraction,Cell Phone (hand-Held),Pick-up Truck,Station Wagon/Sport Utility Vehicle
446,2018-04-02,17:25:00,11691,40.606743,-73.75656,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
447,2018-03-08,06:20:00,11368,40.74357,-73.862755,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
448,2018-03-25,19:37:00,,40.691364,-73.83755,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
449,2018-03-10,21:31:00,10010,40.740692,-73.987595,Following Too Closely,Cell Phone (hands-free),Taxi,Station Wagon/Sport Utility Vehicle
450,2018-03-22,19:00:00,11205,40.697105,-73.95372,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
451,2018-02-26,12:18:00,11226,40.646515,-73.958115,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
452,2018-02-25,16:30:00,11417,40.680305,-73.844536,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
453,2018-02-01,16:57:00,10065,40.764362,-73.96162,Pedestrian/Bicyclist/Other Pedestrian Error/Confusion,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Bike
454,2018-02-13,09:15:00,,40.888577,-73.82814,Cell Phone (hand-Held),Reaction to Uninvolved Vehicle,Sedan,Tractor Truck Diesel
455,2018-02-19,00:17:00,,40.88759,-73.86652,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
456,2018-02-05,10:00:00,10456,40.833088,-73.91904,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
457,2018-02-09,15:15:00,,,,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
458,2018-02-05,11:30:00,,40.69685,-73.96327,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
459,2018-01-17,12:15:00,10455,40.80988,-73.90308,Cell Phone (hands-free),Backing Unsafely,Sedan,Station Wagon/Sport Utility Vehicle
460,2018-01-16,17:55:00,,40.697166,-73.893364,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
461,2018-01-27,19:38:00,11385,40.702374,-73.8888,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
462,2018-01-13,16:40:00,11220,40.64063,-74.025734,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Pick-up Truck
463,2018-01-03,05:02:00,10022,40.760036,-73.97103,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
464,2018-01-18,22:55:00,,40.8807,-73.91931,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
465,2018-01-12,11:25:00,,40.844524,-73.902725,Cell Phone (hands-free),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
466,2018-01-03,08:25:00,10467,40.874313,-73.868164,Driver Inattention/Distraction,Cell Phone (hand-Held),Sedan,Station Wagon/Sport Utility Vehicle
467,2018-01-16,18:40:00,11206,40.700214,-73.94632,Cell Phone (hand-Held),Unspecified,Sedan,Bike
468,2018-01-02,00:30:00,11239,,,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
469,2017-12-27,15:20:00,10467,40.870117,-73.86525,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
470,2017-12-23,11:11:00,10312,40.539837,-74.19577,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
471,2017-12-14,17:15:00,,40.79522,-73.921524,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
472,2017-12-17,22:35:00,,40.834126,-73.916664,Cell Phone (hands-free),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
473,2017-12-29,12:23:00,10470,40.90124,-73.86547,Cell Phone (hand-Held),Failure to Yield Right-of-Way,Station Wagon/Sport Utility Vehicle,Pick-up Truck
474,2017-12-15,06:45:00,,40.792927,-73.94791,Cell Phone (hand-Held),Other Vehicular,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
475,2017-12-23,18:40:00,,40.7549,-73.74548,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
476,2017-12-04,18:40:00,11373,40.74589,-73.88457,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
477,2017-11-10,08:15:00,11354,40.769493,-73.844315,Cell Phone (hand-Held),Unspecified,Sedan,Box Truck
478,2017-11-29,15:55:00,,40.605915,-73.75108,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
479,2017-11-15,14:00:00,11213,40.669098,-73.93666,Passing or Lane Usage Improper,Cell Phone (hand-Held),Sedan,Sedan
480,2017-11-29,12:40:00,10467,40.878563,-73.86574,Cell Phone (hand-Held),Following Too Closely,Pick-up Truck,Sedan
481,2017-11-28,10:15:00,,40.756424,-73.7403,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
482,2017-11-15,09:05:00,,40.838203,-73.9302,Passing or Lane Usage Improper,Cell Phone (hand-Held),Sedan,Box Truck
483,2017-11-26,17:10:00,11212,40.654312,-73.91759,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
484,2017-11-24,03:21:00,,,,Cell Phone (hand-Held),,Sedan,
485,2017-11-09,17:48:00,,40.683094,-73.80576,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
486,2017-10-18,10:40:00,,40.74947,-73.7564,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Sedan
487,2017-10-23,16:13:00,,40.67893,-73.944084,Cell Phone (hand-Held),Unspecified,Bus,Sedan
488,2017-10-28,20:50:00,11234,40.6291,-73.93186,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
489,2017-10-26,16:56:00,10466,40.8831,-73.837654,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
490,2017-10-26,11:00:00,,40.696354,-73.94071,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
491,2017-10-27,15:22:00,,40.79801,-73.827065,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
492,2017-11-02,20:40:00,11434,40.69225,-73.76669,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
493,2017-10-21,10:15:00,11214,40.608746,-74.003494,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Station Wagon/Sport Utility Vehicle
494,2017-11-06,21:11:00,,40.597042,-73.985756,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
495,2017-10-18,21:20:00,11372,40.74899,-73.87099,Failure to Yield Right-of-Way,Cell Phone (hand-Held),Sedan,Sedan
496,2017-11-01,11:10:00,10466,40.888016,-73.83128,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
497,2017-10-05,15:30:00,,40.73851,-73.8065,Passing or Lane Usage Improper,Cell Phone (hands-free),Station Wagon/Sport Utility Vehicle,Sedan
498,2017-10-03,23:30:00,,40.605396,-74.169815,Cell Phone (hand-Held),,Sedan,
499,2017-09-24,01:50:00,,40.75852,-73.938095,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
500,2017-10-02,03:20:00,10468,40.86191,-73.90395,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
501,2017-10-14,13:25:00,,40.82319,-73.855316,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
502,2017-08-25,22:43:00,11218,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
503,2017-09-11,20:00:00,,40.68818,-73.78869,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
504,2017-09-15,20:05:00,,40.81073,-73.91738,Unsafe Lane Changing,Cell Phone (hand-Held),Sedan,Taxi
505,2017-09-02,18:05:00,10456,40.826923,-73.913635,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
506,2017-08-28,09:00:00,,40.606617,-73.98715,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
507,2017-09-16,12:10:00,11221,40.689625,-73.922325,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
508,2017-09-06,06:20:00,,40.75351,-73.8979,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Pick-up Truck
509,2017-08-29,11:30:00,10019,40.765987,-73.98713,Cell Phone (hands-free),Unspecified,Taxi,Pick-up Truck
510,2017-08-20,19:15:00,10001,40.7494,-73.99178,Cell Phone (hands-free),Unspecified,Taxi,Taxi
511,2017-08-23,19:46:00,10454,40.808163,-73.92653,Other Vehicular,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Sedan
512,2017-08-15,18:00:00,11360,40.77835,-73.77704,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Sedan
513,2017-08-18,21:14:00,,40.81175,-73.93144,Following Too Closely,Cell Phone (hand-Held),Sedan,Sedan
514,2017-08-11,17:25:00,11435,40.7024,-73.80818,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
515,2017-08-08,10:30:00,10032,40.83089,-73.941376,Other Vehicular,Cell Phone (hand-Held),Taxi,Sedan
516,2017-08-04,15:30:00,10027,40.80886,-73.95213,Cell Phone (hand-Held),Unspecified,Bus,Sedan
517,2017-07-11,12:30:00,10458,40.86038,-73.88889,Cell Phone (hand-Held),Following Too Closely,Sedan,Sedan
518,2017-07-27,14:40:00,11205,40.69841,-73.956924,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
519,2017-07-21,07:20:00,,40.76259,-73.80464,Cell Phone (hand-Held),Unspecified,Sedan,Pick-up Truck
520,2017-07-16,04:22:00,10460,40.8396,-73.86922,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
521,2017-07-10,19:35:00,10306,40.582756,-74.13041,Cell Phone (hand-Held),,Sedan,
522,2017-07-23,13:00:00,,40.556232,-74.14655,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
523,2017-07-10,21:40:00,10019,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
524,2017-07-17,21:30:00,,40.845108,-73.913025,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
525,2017-07-03,10:05:00,11207,40.681374,-73.90663,Cell Phone (hand-Held),Other Vehicular,Sedan,Station Wagon/Sport Utility Vehicle
526,2017-06-21,17:50:00,11206,40.70119,-73.92817,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
527,2017-06-19,10:59:00,10459,40.82097,-73.890236,Cell Phone (hands-free),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
528,2017-06-28,00:30:00,,40.70383,-73.98877,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
529,2017-06-19,12:10:00,10468,40.87469,-73.8865,Aggressive Driving/Road Rage,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Sedan
530,2017-06-21,15:45:00,10001,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Bus
531,2017-06-11,00:05:00,11691,40.59321,-73.78072,Cell Phone (hand-Held),,Sedan,
532,2017-06-23,17:20:00,11221,40.700478,-73.92534,Cell Phone (hand-Held),Unspecified,Sedan,Pick-up Truck
533,2017-06-14,17:10:00,,40.82733,-73.8498,Cell Phone (hand-Held),Following Too Closely,Station Wagon/Sport Utility Vehicle,Sedan
534,2017-06-20,14:30:00,11375,40.737995,-73.85098,Failure to Yield Right-of-Way,Cell Phone (hand-Held),Sedan,Sedan
535,2017-06-09,11:15:00,11221,40.687798,-73.93304,Cell Phone (hand-Held),Driver Inattention/Distraction,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
536,2017-05-30,03:15:00,,,,Other Vehicular,Cell Phone (hand-Held),Sedan,Sedan
537,2017-06-01,13:30:00,11219,40.632927,-73.98714,Cell Phone (hand-Held),,Sedan,
538,2017-05-31,12:45:00,,40.798256,-73.92402,Passing or Lane Usage Improper,Cell Phone (hand-Held),Sedan,Sedan
539,2017-05-27,09:15:00,10009,40.7292,-73.97747,Cell Phone (hand-Held),Unspecified,Taxi,Sedan
540,2017-05-24,17:30:00,,,,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
541,2017-05-26,08:30:00,,40.66955,-73.94497,Cell Phone (hands-free),Unspecified,Sedan,Sedan
542,2017-05-29,23:15:00,11204,40.620914,-73.9753,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
543,2017-05-21,13:00:00,10456,40.826385,-73.906166,Cell Phone (hand-Held),Unspecified,Sedan,Convertible
544,2017-05-20,16:50:00,,40.558887,-74.1977,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
545,2017-05-02,22:30:00,11365,40.737774,-73.7788,Passenger Distraction,Cell Phone (hand-Held),Sedan,Station Wagon/Sport Utility Vehicle
546,2017-04-22,18:56:00,11377,40.741863,-73.90751,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
547,2017-04-24,19:15:00,10306,40.55234,-74.133194,Cell Phone (hand-Held),Unspecified,Bus,Sedan
548,2017-04-29,00:15:00,,40.675755,-73.95977,Cell Phone (hand-Held),Unspecified,Taxi,Sedan
549,2017-05-02,22:30:00,11365,40.737774,-73.7788,Driver Inexperience,Cell Phone (hands-free),Sedan,Station Wagon/Sport Utility Vehicle
550,2017-05-01,16:00:00,,40.719704,-73.97464,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
551,2017-05-11,16:00:00,10039,40.826088,-73.93584,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
552,2017-04-20,12:30:00,10033,40.8442,-73.93566,Cell Phone (hands-free),Unspecified,Taxi,Sedan
553,2017-03-27,13:50:00,,40.803757,-73.939995,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
554,2017-04-10,12:30:00,10035,40.802666,-73.93868,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
555,2017-04-12,00:50:00,,40.598133,-74.18061,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
556,2017-04-13,11:40:00,,40.767612,-73.950005,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
557,2017-04-13,17:55:00,,,,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
558,2017-04-10,14:15:00,10455,40.812897,-73.90145,Failure to Yield Right-of-Way,Cell Phone (hands-free),Pick-up Truck,Bike
559,2017-04-09,04:50:00,11220,40.645435,-74.017204,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
560,2017-03-27,19:00:00,,40.52609,-74.18032,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
561,2017-04-15,11:15:00,11236,40.636574,-73.911644,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
562,2017-04-05,14:30:00,,40.732403,-74.0102,Cell Phone (hand-Held),Unspecified,Sedan,Bus
563,2017-03-24,05:00:00,11206,40.711643,-73.94392,Cell Phone (hand-Held),Unspecified,Garbage or Refuse,Sedan
564,2017-03-07,18:50:00,10304,40.615204,-74.084656,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Sedan
565,2017-02-25,16:15:00,,40.756096,-73.74655,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
566,2017-03-04,17:50:00,10001,40.752686,-73.994675,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
567,2017-03-22,23:50:00,11235,40.58371,-73.94739,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
568,2017-03-10,16:00:00,11226,40.650806,-73.94958,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
569,2017-03-21,11:38:00,10021,40.76975,-73.96061,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
570,2017-02-28,23:55:00,,40.508453,-74.23566,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
571,2017-03-09,16:40:00,10026,40.799435,-73.9553,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
572,2017-01-27,08:35:00,,40.82705,-73.87104,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Station Wagon/Sport Utility Vehicle
573,2017-02-10,12:35:00,,40.851654,-73.91566,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
574,2017-02-16,10:55:00,10473,40.8224,-73.86715,Cell Phone (hand-Held),Unspecified,Taxi,Sedan
575,2017-02-23,16:30:00,11207,40.68122,-73.90561,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
576,2017-02-19,07:00:00,11435,40.698433,-73.808556,Cell Phone (hand-Held),,Sedan,
577,2017-02-14,09:30:00,10032,40.83778,-73.94403,Other Vehicular,Cell Phone (hand-Held),Sedan,Taxi
578,2017-01-18,19:06:00,,40.834198,-73.85169,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
579,2016-12-26,17:50:00,10010,40.740356,-73.99046,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Taxi
580,2016-12-30,16:00:00,,,,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
581,2017-01-17,07:45:00,10029,40.797775,-73.94172,Cell Phone (hands-free),Unspecified,Taxi,Sedan
582,2017-01-13,12:30:00,11361,40.761097,-73.76386,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
583,2016-12-20,00:45:00,10002,40.717342,-73.99118,Cell Phone (hand-Held),Unspecified,Taxi,Station Wagon/Sport Utility Vehicle
584,2016-12-15,10:35:00,,40.598595,-74.140045,Cell Phone (hand-Held),Unspecified,Sedan,Lift Boom
585,2016-12-14,21:54:00,,40.778492,-73.92583,Cell Phone (hand-Held),Unspecified,Taxi,Sedan
586,2016-12-16,23:20:00,10453,40.857708,-73.9043,Cell Phone (hand-Held),,Sedan,
587,2016-12-16,16:53:00,10467,40.876717,-73.88027,Reaction to Uninvolved Vehicle,Cell Phone (hands-free),Station Wagon/Sport Utility Vehicle,Sedan
588,2016-11-07,16:35:00,,40.87924,-73.91987,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
589,2016-11-25,16:58:00,,40.74315,-73.831924,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
590,2016-11-11,20:20:00,,40.675533,-73.81448,Cell Phone (hand-Held),Unspecified,Bike,
591,2016-11-09,16:30:00,,40.563915,-74.11637,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
592,2016-11-09,14:15:00,11354,40.76439,-73.82554,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
593,2016-11-14,09:45:00,11358,40.758232,-73.79768,Cell Phone (hand-Held),Unspecified,Sedan,Pick-up Truck
594,2016-11-28,13:20:00,,40.7406,-73.879326,Cell Phone (hand-Held),Unspecified,Taxi,Sedan
595,2016-11-17,11:00:00,,40.711166,-73.9489,Cell Phone (hands-free),Unspecified,Box Truck,Sedan
596,2016-10-22,21:55:00,10026,40.800686,-73.952515,Cell Phone (hand-Held),Pedestrian/Bicyclist/Other Pedestrian Error/Confusion,Station Wagon/Sport Utility Vehicle,Bike
597,2016-10-12,00:37:00,11422,40.67546,-73.73385,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
598,2016-10-22,14:00:00,,40.680855,-74.00305,Cell Phone (hand-Held),Unspecified,Refrigerated Van,
599,2016-10-28,22:40:00,10040,40.85186,-73.92816,Cell Phone (hand-Held),Unspecified,Pick-up Truck,Pick-up Truck
600,2016-10-15,12:44:00,10454,40.81099,-73.914856,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
601,2016-10-10,20:06:00,,40.820145,-73.890656,Following Too Closely,Cell Phone (hand-Held),Sedan,Taxi
602,2016-10-19,19:05:00,11216,40.680153,-73.9375,Cell Phone (hand-Held),Unsafe Lane Changing,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
603,2016-10-18,08:40:00,,40.837315,-73.92331,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
604,2016-10-29,20:45:00,,40.826374,-73.85292,Cell Phone (hand-Held),,,
605,2016-10-23,07:40:00,,,,Cell Phone (hands-free),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
606,2016-09-19,12:30:00,,40.801754,-73.93121,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
607,2016-09-16,17:00:00,10016,40.740307,-73.97607,Cell Phone (hand-Held),Unspecified,Convertible,Station Wagon/Sport Utility Vehicle
608,2016-10-02,21:15:00,,40.663284,-73.96096,Cell Phone (hand-Held),Unspecified,Sedan,Taxi
609,2016-08-23,00:40:00,10458,40.87138,-73.88379,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
610,2016-09-01,20:20:00,,40.751167,-73.72707,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
611,2016-08-20,09:30:00,11101,40.752094,-73.925964,Traffic Control Disregarded,Cell Phone (hand-Held),Box Truck,Station Wagon/Sport Utility Vehicle
612,2016-09-10,14:00:00,10468,40.868282,-73.90107,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
613,2016-08-29,02:30:00,11220,40.643356,-74.00139,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
614,2016-08-24,09:41:00,,,,Cell Phone (hand-Held),Driver Inattention/Distraction,Sedan,Sedan
615,2016-09-07,08:59:00,,40.604153,-74.05198,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
616,2016-08-25,23:15:00,11216,40.68852,-73.95005,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
617,2016-08-26,19:45:00,11217,40.68444,-73.97772,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
618,2016-09-08,08:40:00,,,,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
619,2016-09-10,18:27:00,10013,40.71948,-74.00183,Driver Inattention/Distraction,Cell Phone (hand-Held),Sedan,Bike
620,2016-08-29,17:35:00,11432,40.725647,-73.7917,Cell Phone (hand-Held),,,
621,2016-09-05,13:00:00,,40.691532,-73.993744,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
622,2016-08-28,00:45:00,11233,40.68203,-73.93487,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
623,2016-09-01,12:00:00,,40.803024,-73.93632,Cell Phone (hand-Held),Turning Improperly,PK,Station Wagon/Sport Utility Vehicle
624,2016-09-04,09:45:00,11213,40.674435,-73.93059,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
625,2016-08-18,17:32:00,,40.690006,-73.98373,Cell Phone (hand-Held),Unspecified,Sedan,
626,2016-08-05,19:19:00,,40.679634,-73.94959,Passing or Lane Usage Improper,Cell Phone (hand-Held),Sedan,Station Wagon/Sport Utility Vehicle
627,2016-07-27,18:37:00,,40.803143,-73.97256,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
628,2016-08-12,17:13:00,,40.601734,-73.935036,Cell Phone (hands-free),Unspecified,Sedan,Pick-up Truck
629,2016-08-04,18:00:00,11206,40.697247,-73.932846,Reaction to Uninvolved Vehicle,Cell Phone (hand-Held),Bike,Station Wagon/Sport Utility Vehicle
630,2016-07-30,16:12:00,,40.8047,-73.91243,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
631,2016-08-15,00:30:00,,40.88353,-73.8779,Cell Phone (hands-free),Unsafe Speed,Sedan,Station Wagon/Sport Utility Vehicle
632,2016-08-06,12:45:00,11221,40.687767,-73.91902,Unsafe Lane Changing,Cell Phone (hand-Held),Sedan,Station Wagon/Sport Utility Vehicle
633,2016-08-12,11:30:00,10036,40.758705,-73.98928,Cell Phone (hand-Held),Unspecified,Taxi,Station Wagon/Sport Utility Vehicle
634,2016-07-30,06:40:00,,40.844753,-73.90539,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
635,2016-08-15,13:10:00,10457,40.84502,-73.890366,Cell Phone (hand-Held),Unspecified,Sedan,Bike
636,2016-08-06,16:45:00,11369,40.762196,-73.870415,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
637,2016-08-02,18:20:00,10306,40.565884,-74.1089,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
638,2016-08-03,15:30:00,11236,40.6379,-73.90085,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Bike
639,2016-07-09,20:00:00,11221,40.689537,-73.9283,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
640,2016-06-29,15:10:00,,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
641,2016-07-23,04:05:00,,,,Cell Phone (hand-Held),Reaction to Uninvolved Vehicle,4 dr sedan,Tractor Truck Diesel
642,2016-07-16,02:00:00,,40.75687,-73.98897,Cell Phone (hand-Held),Unspecified,4 dr sedan,2 dr sedan
643,2016-06-28,12:15:00,,,,Cell Phone (hand-Held),Unspecified,4 dr sedan,Station Wagon/Sport Utility Vehicle
644,2016-07-16,02:50:00,,40.749054,-73.99576,Passenger Distraction,Cell Phone (hand-Held),Taxi,Taxi
645,2016-07-15,14:07:00,,40.792545,-73.94104,Following Too Closely,Cell Phone (hand-Held),4 dr sedan,Station Wagon/Sport Utility Vehicle
646,2016-07-22,18:00:00,,,,Cell Phone (hand-Held),Unspecified,4 dr sedan,Sedan
647,2016-06-28,15:00:00,10310,40.629684,-74.11123,Cell Phone (hand-Held),Glare,Station Wagon/Sport Utility Vehicle,4 dr sedan
648,2016-07-01,22:00:00,11235,40.58313,-73.9654,Cell Phone (hand-Held),Unspecified,4 dr sedan,4 dr sedan
649,2016-06-08,06:20:00,,40.66662,-73.835464,Cell Phone (hand-Held),Unspecified,4 dr sedan,
650,2016-06-14,21:00:00,10022,40.76276,-73.973465,Cell Phone (hands-free),Cell Phone (hands-free),Sedan,Pick-up Truck
651,2016-06-21,04:50:00,,40.72176,-73.76001,Cell Phone (hand-Held),Unspecified,4 dr sedan,Station Wagon/Sport Utility Vehicle
652,2016-06-25,10:30:00,10019,,,Cell Phone (hand-Held),,2 dr sedan,
653,2016-06-08,11:45:00,10018,40.75415,-73.99409,Cell Phone (hand-Held),,Taxi,
654,2016-06-21,20:30:00,10307,40.51166,-74.24026,Cell Phone (hand-Held),Unspecified,2 dr sedan,2 dr sedan
655,2016-06-17,22:05:00,11420,40.668552,-73.80987,Cell Phone (hand-Held),Unspecified,4 dr sedan,4 dr sedan
656,2016-06-17,15:06:00,,,,Cell Phone (hands-free),Unspecified,4 dr sedan,4 dr sedan
657,2016-05-27,14:30:00,10310,40.63959,-74.12142,Cell Phone (hand-Held),Failure to Yield Right-of-Way,Station Wagon/Sport Utility Vehicle,4 dr sedan
658,2016-05-23,22:29:00,10463,40.879128,-73.897354,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
659,2016-05-19,13:10:00,,40.833412,-73.85906,Cell Phone (hand-Held),Driver Inattention/Distraction,Tractor Truck Gasoline,4 dr sedan
660,2016-05-18,09:48:00,10452,40.840504,-73.92835,Cell Phone (hand-Held),Unspecified,4 dr sedan,4 dr sedan
661,2016-05-24,12:20:00,11235,40.58904,-73.94458,Cell Phone (hands-free),Unspecified,4 dr sedan,Station Wagon/Sport Utility Vehicle
662,2016-05-29,11:30:00,10470,40.899204,-73.865105,Cell Phone (hand-Held),Other Vehicular,Station Wagon/Sport Utility Vehicle,4 dr sedan
663,2016-05-18,11:30:00,,,,Cell Phone (hands-free),Unspecified,4 dr sedan,Flat Bed
664,2016-05-23,13:24:00,11222,40.73046,-73.9515,Cell Phone (hand-Held),Unspecified,PK,4 dr sedan
665,2016-05-31,17:55:00,10034,40.86446,-73.91895,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,4 dr sedan
666,2016-04-21,22:30:00,,40.664356,-73.734535,Cell Phone (hand-Held),Unspecified,4 dr sedan,4 dr sedan
667,2016-04-26,04:30:00,11236,,,Cell Phone (hand-Held),Unspecified,4 dr sedan,Station Wagon/Sport Utility Vehicle
668,2016-05-09,17:30:00,,,,Cell Phone (hand-Held),Unspecified,,
669,2016-04-15,16:30:00,,40.82926,-73.93484,Cell Phone (hand-Held),Unspecified,4 dr sedan,4 dr sedan
670,2016-04-20,21:50:00,11219,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,4 dr sedan
671,2016-04-25,14:50:00,11229,,,Cell Phone (hand-Held),Unspecified,2 dr sedan,2 dr sedan
672,2016-04-26,04:30:00,,40.683094,-73.80596,Cell Phone (hand-Held),,4 dr sedan,
673,2016-04-30,15:45:00,,,,Cell Phone (hand-Held),Unspecified,4 dr sedan,Box Truck
674,2016-04-20,11:20:00,10471,40.896915,-73.901955,Cell Phone (hand-Held),,4 dr sedan,
675,2016-04-30,20:20:00,11433,,,Cell Phone (hand-Held),,UNKNO,
676,2016-04-20,15:35:00,11215,40.671726,-73.987564,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,4 dr sedan
677,2016-04-16,17:50:00,10456,40.837864,-73.9114,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,4 dr sedan
678,2016-04-25,11:12:00,,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,4 dr sedan
679,2016-03-16,13:30:00,11235,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
680,2016-03-17,08:36:00,,40.777554,-73.94889,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
681,2016-03-28,01:55:00,,40.671505,-73.90734,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
682,2016-04-09,14:00:00,11367,40.726223,-73.812996,Cell Phone (hand-Held),Unspecified,4 dr sedan,2 dr sedan
683,2016-03-19,01:00:00,,,,Cell Phone (hand-Held),Unspecified,4 dr sedan,
684,2016-04-06,16:00:00,11358,,,Failure to Yield Right-of-Way,Cell Phone (hand-Held),4 dr sedan,Station Wagon/Sport Utility Vehicle
685,2016-03-29,12:40:00,10468,,,Cell Phone (hand-Held),Unspecified,UNKNO,Station Wagon/Sport Utility Vehicle
686,2016-04-11,16:00:00,10462,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
687,2016-04-06,22:40:00,10005,,,Cell Phone (hand-Held),,4 dr sedan,
688,2016-04-06,17:50:00,10305,,,Cell Phone (hands-free),Unspecified,Sedan,4 dr sedan
689,2016-04-09,10:15:00,11237,,,Cell Phone (hand-Held),Unspecified,Sedan,
690,2016-03-19,16:30:00,,,,Cell Phone (hand-Held),Unspecified,4 dr sedan,4 dr sedan
691,2016-03-31,09:30:00,11418,,,Other Vehicular,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,
692,2016-04-11,17:15:00,,40.823914,-73.87644,Cell Phone (hands-free),Unspecified,4 dr sedan,4 dr sedan
693,2016-04-11,08:50:00,10012,,,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
694,2016-03-08,19:30:00,11228,40.6101563,-74.0120221,Cell Phone (hands-free),Cell Phone (hands-free),PASSENGER VEHICLE,PASSENGER VEHICLE
695,2016-03-10,11:30:00,11208,40.6713407,-73.8819394,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
696,2016-03-09,07:15:00,,40.7190565,-73.8331917,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
697,2016-03-02,08:58:00,10017,40.7487997,-73.969846,Other Vehicular,Cell Phone (hands-free),PASSENGER VEHICLE,PASSENGER VEHICLE
698,2016-02-18,17:30:00,11220,40.6408367,-74.0184306,Other Vehicular,Cell Phone (hands-free),SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
699,2016-03-14,11:30:00,11692,,,Cell Phone (hand-Held),Unspecified,Van,Station Wagon/Sport Utility Vehicle
700,2016-03-02,09:10:00,,40.7263443,-73.7650719,Cell Phone (hand-held),Unspecified,SPORT UTILITY / STATION WAGON,PICK-UP TRUCK
701,2016-03-12,23:15:00,10002,40.7224697,-73.9871351,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
702,2016-03-15,07:10:00,10025,,,Cell Phone (hands-free),,4 dr sedan,
703,2016-02-19,10:26:00,11207,40.6757357,-73.8968533,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
704,2016-01-26,22:50:00,,,,Cell Phone (hands-free),Cell Phone (hands-free),PASSENGER VEHICLE,PASSENGER VEHICLE
705,2016-02-10,17:30:00,11217,40.6840525,-73.9774579,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,UNKNOWN
706,2016-02-07,16:30:00,11209,40.6308307,-74.0250857,Cell Phone (hands-free),,PASSENGER VEHICLE,PASSENGER VEHICLE
707,2016-01-21,10:45:00,11357,40.7914838,-73.8148574,Cell Phone (hands-free),Oversized Vehicle,SPORT UTILITY / STATION WAGON,VAN
708,2016-01-27,08:00:00,,,,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
709,2016-02-01,11:20:00,11220,40.6414667,-73.9997586,Cell Phone (hands-free),Unspecified,UNKNOWN,SPORT UTILITY / STATION WAGON
710,2016-01-29,17:14:00,10001,40.7533873,-73.996304,Cell Phone (hands-free),Unspecified,SMALL COM VEH(4 TIRES) ,BUS
711,2016-01-20,15:25:00,,,,Cell Phone (hands-free),Unspecified,PICK-UP TRUCK,PASSENGER VEHICLE
712,2015-12-30,21:00:00,10016,40.7440912,-73.9763477,Cell Phone (hands-free),,PASSENGER VEHICLE,
713,2016-01-07,10:05:00,11378,40.7229902,-73.9106843,Driver Inattention/Distraction,Cell Phone (hands-free),PASSENGER VEHICLE,UNKNOWN
714,2016-01-01,09:05:00,11236,40.6320133,-73.9056036,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,UNKNOWN
715,2016-01-15,17:34:00,,,,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
716,2016-01-14,23:35:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,BICYCLE
717,2016-01-10,23:50:00,11205,40.6980388,-73.9628402,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
718,2016-01-06,11:00:00,11206,40.7053194,-73.9352482,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,UNKNOWN
719,2015-12-29,18:40:00,11411,40.6975248,-73.7468181,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
720,2015-12-22,19:28:00,11201,40.6896895,-73.9923627,Cell Phone (hand-held),Unspecified,OTHER,OTHER
721,2015-11-02,11:20:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,TAXI
722,2015-12-04,16:00:00,10306,40.5578534,-74.1266987,Cell Phone (hand-held),Unspecified,SPORT UTILITY / STATION WAGON,BUS
723,2015-12-10,16:23:00,11223,40.6034741,-73.9788283,Cell Phone (hand-held),Cell Phone (hand-held),BUS,PASSENGER VEHICLE
724,2015-12-18,09:55:00,10029,40.7880564,-73.9443222,Other Vehicular,Cell Phone (hands-free),PASSENGER VEHICLE,SMALL COM VEH(4 TIRES) 
725,2015-12-08,23:30:00,11355,40.7502451,-73.8088256,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
726,2015-12-16,12:30:00,10460,40.8353892,-73.8878207,Driver Inattention/Distraction,Cell Phone (hand-held),PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
727,2015-12-16,20:40:00,10306,40.5673935,-74.1522826,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
728,2015-11-24,12:55:00,11106,40.7632002,-73.9210809,Cell Phone (hands-free),Unspecified,LARGE COM VEH(6 OR MORE TIRES),PASSENGER VEHICLE
729,2015-11-30,09:20:00,11204,40.618242,-73.9840682,Cell Phone (hands-free),,UNKNOWN,
730,2015-11-04,09:28:00,11220,40.6387349,-74.0133568,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
731,2015-11-17,14:10:00,10003,40.7348379,-73.9907554,Cell Phone (hands-free),Unspecified,TAXI,LIVERY VEHICLE
732,2015-11-16,18:30:00,11204,40.6106328,-73.9801803,Cell Phone (hands-free),,PASSENGER VEHICLE,
733,2015-11-21,11:50:00,11212,40.6547385,-73.9069229,Cell Phone (hand-held),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
734,2015-11-08,18:00:00,11214,40.6064564,-73.989131,Cell Phone (hand-held),Cell Phone (hand-held),UNKNOWN,BICYCLE
735,2015-11-14,13:40:00,10075,40.771079,-73.947582,Cell Phone (hand-held),Cell Phone (hand-held),LIVERY VEHICLE,LIVERY VEHICLE
736,2015-10-29,11:25:00,11222,40.7289951,-73.9506603,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,TAXI
737,2015-11-07,14:45:00,,40.8052248,-73.9321277,Cell Phone (hands-free),Outside Car Distraction,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
738,2015-11-05,13:50:00,10038,40.7127265,-73.9979836,Cell Phone (hands-free),Other Vehicular,VAN,PASSENGER VEHICLE
739,2015-11-13,07:00:00,11385,40.7034347,-73.9118069,Cell Phone (hands-free),Unspecified,UNKNOWN,SPORT UTILITY / STATION WAGON
740,2015-11-03,00:55:00,10038,40.7096605,-74.0048261,Cell Phone (hand-held),,TAXI,
741,2015-11-19,16:10:00,11433,40.6981059,-73.7826956,Cell Phone (hands-free),Other Vehicular,SPORT UTILITY / STATION WAGON,VAN
742,2015-11-23,23:52:00,11228,40.6151609,-74.0239596,Driver Inattention/Distraction,Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
743,2015-10-22,10:10:00,,40.8040684,-73.9311544,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
744,2015-10-22,18:30:00,,,,Cell Phone (hands-free),Cell Phone (hands-free),PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
745,2015-10-23,14:25:00,11357,40.7864769,-73.8162689,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
746,2015-10-05,16:00:00,11207,40.6541418,-73.8873109,Prescription Medication,Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
747,2015-10-15,10:23:00,10036,40.7572323,-73.9897922,Lost Consciousness,Cell Phone (hands-free),BUS,SMALL COM VEH(4 TIRES) 
748,2015-10-05,15:54:00,11207,40.6756735,-73.8978448,Cell Phone (hands-free),Outside Car Distraction,PASSENGER VEHICLE,PASSENGER VEHICLE
749,2015-10-01,22:40:00,10003,40.7340111,-73.984773,Cell Phone (hand-held),Driver Inattention/Distraction,LIVERY VEHICLE,LIVERY VEHICLE
750,2015-09-27,14:00:00,11237,40.7058792,-73.93031,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,UNKNOWN
751,2015-09-24,09:40:00,,,,Cell Phone (hands-free),,PASSENGER VEHICLE,PASSENGER VEHICLE
752,2015-09-22,13:30:00,10011,40.7464925,-74.0013245,Cell Phone (hand-held),Unspecified,SMALL COM VEH(4 TIRES) ,LIVERY VEHICLE
753,2015-09-06,16:30:00,11215,40.6764116,-73.9804599,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
754,2015-09-14,19:00:00,11216,40.6767222,-73.9470722,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,BICYCLE
755,2015-09-17,08:00:00,10003,40.7332923,-73.9871799,Fatigued/Drowsy,Cell Phone (hands-free),PASSENGER VEHICLE,PASSENGER VEHICLE
756,2015-09-14,11:37:00,11201,40.6948378,-73.9839237,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,VAN
757,2015-09-13,22:00:00,10472,40.8348371,-73.8668076,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
758,2015-09-28,16:30:00,11101,40.7431952,-73.9367235,Backing Unsafely,Cell Phone (hands-free),PASSENGER VEHICLE,PASSENGER VEHICLE
759,2015-09-22,17:00:00,10457,40.8406797,-73.8982709,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,BUS
760,2015-09-05,11:20:00,10025,40.7940523,-73.9703673,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,BUS
761,2015-08-29,23:00:00,,,,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
762,2015-08-27,14:20:00,,40.7241721,-73.77419,Cell Phone (hand-held),,SPORT UTILITY / STATION WAGON,
763,2015-08-13,09:45:00,10014,40.7302269,-74.0068554,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,SMALL COM VEH(4 TIRES) 
764,2015-08-30,19:00:00,10459,40.8209925,-73.8958803,Cell Phone (hands-free),Driver Inexperience,PASSENGER VEHICLE,PASSENGER VEHICLE
765,2015-08-14,16:40:00,11201,40.688616,-73.9891681,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
766,2015-08-14,11:30:00,11201,40.6889031,-73.9809286,Cell Phone (hands-free),Other Vehicular,LARGE COM VEH(6 OR MORE TIRES),SMALL COM VEH(4 TIRES) 
767,2015-08-18,16:00:00,10312,40.5428472,-74.200238,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
768,2015-08-24,12:50:00,11379,40.7126469,-73.8993537,Cell Phone (hand-held),Prescription Medication,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
769,2015-08-11,16:15:00,11211,40.7093526,-73.9624155,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,UNKNOWN
770,2015-09-01,09:25:00,,40.8049944,-73.9113446,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SMALL COM VEH(4 TIRES) 
771,2015-08-24,11:28:00,11218,40.6387346,-73.9846722,Cell Phone (hands-free),Unspecified,OTHER,SPORT UTILITY / STATION WAGON
772,2015-08-07,08:20:00,11419,40.6938306,-73.8288643,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,BICYCLE
773,2015-07-21,09:53:00,10467,40.8802375,-73.8719168,Cell Phone (hand-held),Unspecified,VAN,SPORT UTILITY / STATION WAGON
774,2015-07-26,19:44:00,10002,40.7160227,-73.99131,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
775,2015-07-29,19:36:00,11216,40.6879764,-73.9548301,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,BICYCLE
776,2015-08-03,13:35:00,11375,40.7295007,-73.8457053,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,UNKNOWN
777,2015-07-20,08:56:00,,40.7549013,-73.7454772,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,BUS
778,2015-08-05,19:00:00,11234,40.6098096,-73.9224976,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
779,2015-07-22,12:18:00,11375,40.7367475,-73.852476,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
780,2015-08-04,13:00:00,11226,40.6431277,-73.9506661,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
781,2015-07-14,08:00:00,11418,40.6953527,-73.8208619,Cell Phone (hands-free),,SPORT UTILITY / STATION WAGON,PICK-UP TRUCK
782,2015-07-15,14:10:00,10004,40.70495,-74.0115487,Cell Phone (hands-free),,SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
783,2015-07-08,11:40:00,10065,40.7646819,-73.9642975,Cell Phone (hands-free),Outside Car Distraction,LARGE COM VEH(6 OR MORE TIRES),PASSENGER VEHICLE
784,2015-06-18,13:35:00,10011,40.7341384,-73.9991845,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SMALL COM VEH(4 TIRES) 
785,2015-06-26,19:50:00,,,,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
786,2015-07-07,20:52:00,10030,40.8240317,-73.9447582,Cell Phone (hand-held),Passenger Distraction,PASSENGER VEHICLE,BICYCLE
787,2015-07-03,23:50:00,11236,40.6338025,-73.8896944,Cell Phone (hand-held),Fell Asleep,PASSENGER VEHICLE,UNKNOWN
788,2015-06-26,08:22:00,10022,40.7567642,-73.9671533,Turning Improperly,Cell Phone (hands-free),TAXI,PICK-UP TRUCK
789,2015-06-24,21:55:00,11234,40.6327553,-73.9298351,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
790,2015-06-26,12:45:00,11354,40.7616241,-73.8220734,Cell Phone (hand-held),Unspecified,TAXI,VAN
791,2015-06-20,19:25:00,10455,40.8190975,-73.914562,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,TAXI
792,2015-06-23,09:21:00,11201,40.6920875,-73.9834015,Cell Phone (hands-free),Unspecified,PICK-UP TRUCK,SMALL COM VEH(4 TIRES) 
793,2015-05-27,15:10:00,11209,40.6239985,-74.0367259,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,VAN
794,2015-05-29,07:00:00,,40.7328231,-73.8683917,Cell Phone (hands-free),Unspecified,PICK-UP TRUCK,PASSENGER VEHICLE
795,2015-06-10,00:34:00,10025,40.7979178,-73.9638463,Cell Phone (hands-free),Unspecified,LIVERY VEHICLE,SPORT UTILITY / STATION WAGON
796,2015-06-05,01:30:00,10301,40.6196995,-74.1077068,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
797,2015-05-26,19:09:00,,,,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
798,2015-06-10,16:05:00,10025,40.7935573,-73.967016,Cell Phone (hands-free),Cell Phone (hands-free),VAN,TAXI
799,2015-06-14,18:35:00,11222,40.7226015,-73.9371074,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
800,2015-05-18,18:38:00,11226,40.6548405,-73.9596963,Cell Phone (hands-free),Unspecified,LARGE COM VEH(6 OR MORE TIRES),SMALL COM VEH(4 TIRES) 
801,2015-05-07,13:05:00,11207,40.6618355,-73.8931046,Physical Disability,Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
802,2015-05-15,15:15:00,10003,40.7339788,-73.9909432,Cell Phone (hands-free),Unspecified,SMALL COM VEH(4 TIRES) ,VAN
803,2015-05-05,19:15:00,,40.7347702,-73.8615893,Cell Phone (hands-free),,BUS,SPORT UTILITY / STATION WAGON
804,2015-05-03,15:30:00,,,,Cell Phone (hands-free),Cell Phone (hands-free),SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
805,2015-05-19,16:05:00,10013,40.7184302,-74.0005303,Cell Phone (hands-free),Fatigued/Drowsy,LIVERY VEHICLE,VAN
806,2015-05-12,09:55:00,10019,40.7679171,-73.9857147,Turning Improperly,Cell Phone (hands-free),PASSENGER VEHICLE,LIVERY VEHICLE
807,2015-05-08,03:30:00,11208,40.6865947,-73.8679871,Driver Inexperience,Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
808,2015-05-21,08:49:00,10022,40.7622265,-73.9681866,Cell Phone (hands-free),,TAXI,PASSENGER VEHICLE
809,2015-05-06,18:20:00,10309,40.5504899,-74.2147805,Fatigued/Drowsy,Cell Phone (hands-free),PASSENGER VEHICLE,PASSENGER VEHICLE
810,2015-05-11,16:24:00,11206,40.711815,-73.9379797,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,LARGE COM VEH(6 OR MORE TIRES)
811,2015-04-22,23:10:00,,,,Other Vehicular,Cell Phone (hands-free),PASSENGER VEHICLE,UNKNOWN
812,2015-04-24,13:30:00,,40.7165284,-73.8230706,Cell Phone (hand-held),Unspecified,SPORT UTILITY / STATION WAGON,BUS
813,2015-04-03,17:00:00,10036,40.758981,-73.9959428,Failure to Yield Right-of-Way,Cell Phone (hands-free),PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
814,2015-03-26,18:47:00,11368,40.7578241,-73.8609985,Aggressive Driving/Road Rage,Cell Phone (hands-free),PASSENGER VEHICLE,PASSENGER VEHICLE
815,2015-04-01,07:00:00,11366,40.7278033,-73.8051521,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
816,2015-03-29,15:05:00,10459,40.8283888,-73.8950593,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
817,2015-04-04,08:30:00,11355,40.7533853,-73.8190924,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,UNKNOWN
818,2015-03-31,06:19:00,10021,40.7664937,-73.9569573,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,TAXI
819,2015-03-04,11:40:00,,40.7247837,-73.935689,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
820,2015-03-01,15:20:00,11225,40.6641098,-73.960336,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,UNKNOWN
821,2015-03-22,16:25:00,,40.7545534,-73.7431647,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
822,2015-03-03,20:25:00,11372,40.7477341,-73.8829986,Cell Phone (hands-free),Fatigued/Drowsy,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
823,2015-03-10,09:55:00,11355,40.7446403,-73.8335444,Cell Phone (hands-free),Backing Unsafely,PASSENGER VEHICLE,PASSENGER VEHICLE
824,2015-03-12,16:30:00,10013,40.7187759,-73.9956999,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,BICYCLE
825,2015-02-04,13:15:00,,,,Cell Phone (hand-held),Driver Inattention/Distraction,PASSENGER VEHICLE,PASSENGER VEHICLE
826,2015-02-01,17:00:00,10016,40.7488862,-73.9758407,Cell Phone (hand-held),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
827,2015-02-11,00:10:00,,,,Fatigued/Drowsy,Cell Phone (hand-held),SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
828,2015-02-10,10:00:00,10455,40.8138832,-73.9118122,Cell Phone (hands-free),Other Vehicular,SPORT UTILITY / STATION WAGON,VAN
829,2015-01-23,20:40:00,,,,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
830,2015-01-24,17:30:00,10036,40.7603012,-73.9949825,Cell Phone (hands-free),,PASSENGER VEHICLE,TAXI
831,2015-01-22,06:30:00,,40.7461162,-73.7357595,Cell Phone (hands-free),Unspecified,OTHER,SPORT UTILITY / STATION WAGON
832,2015-01-02,11:55:00,11362,40.763883,-73.7267076,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
833,2015-01-01,04:25:00,11103,40.7660832,-73.9077096,Cell Phone (hand-held),Unspecified,SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
834,2015-01-18,16:00:00,11238,40.6714058,-73.9613194,Backing Unsafely,Cell Phone (hands-free),SPORT UTILITY / STATION WAGON,TAXI
835,2014-12-18,18:15:00,11206,40.7008903,-73.9422022,Cell Phone (hand-held),Turning Improperly,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
836,2014-11-15,01:00:00,11209,40.6314641,-74.0277916,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,LIVERY VEHICLE
837,2014-11-06,02:25:00,10012,40.7206259,-73.9949711,Cell Phone (hands-free),Pavement Slippery,PASSENGER VEHICLE,TAXI
838,2014-10-29,19:35:00,11210,40.6142236,-73.9474279,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
839,2014-10-29,09:55:00,,40.7967215,-73.9761722,Driver Inattention/Distraction,Cell Phone (hands-free),SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
840,2014-11-23,16:45:00,11378,40.7241523,-73.8986833,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
841,2014-10-29,19:35:00,11210,40.6142236,-73.9474279,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
842,2014-10-24,17:30:00,11236,40.6388234,-73.8993929,Cell Phone (hand-held),Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
843,2014-10-25,10:55:00,11203,40.642384,-73.9253821,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
844,2014-10-10,11:40:00,10455,40.818461,-73.9148771,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
845,2014-10-16,18:53:00,,40.7542629,-73.7433292,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
846,2014-10-15,19:45:00,10027,40.8141864,-73.9508609,Cell Phone (hands-free),Cell Phone (hands-free),BUS,SPORT UTILITY / STATION WAGON
847,2014-09-16,11:45:00,11436,40.6674727,-73.7938654,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
848,2014-09-05,14:00:00,11216,40.6781564,-73.9441507,Cell Phone (hand-held),,PASSENGER VEHICLE,OTHER
849,2014-09-12,23:50:00,11215,40.6680296,-73.9839446,Fatigued/Drowsy,Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
850,2014-08-27,10:48:00,11217,40.6770483,-73.9800307,Cell Phone (hand-held),Unspecified,OTHER,UNKNOWN
851,2014-08-26,13:45:00,10003,40.735214,-73.9917152,Turning Improperly,Cell Phone (hands-free),TAXI,TAXI
852,2014-08-20,23:30:00,10011,40.738552,-73.9996824,Cell Phone (hands-free),Outside Car Distraction,PASSENGER VEHICLE,PICK-UP TRUCK
853,2014-08-26,20:08:00,10037,40.8146733,-73.9362111,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
854,2014-08-27,09:48:00,10471,40.907506,-73.8965479,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
855,2014-08-28,01:10:00,,,,Driver Inattention/Distraction,Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
856,2014-08-02,19:18:00,,,,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
857,2014-08-19,11:35:00,10013,40.7233076,-74.00298,Cell Phone (hands-free),,,
858,2014-08-02,07:45:00,,40.8448213,-73.836988,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,VAN
859,2014-07-10,16:33:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,UNKNOWN
860,2014-07-01,17:00:00,11379,40.7205277,-73.8722706,Cell Phone (hand-held),Other Electronic Device,PASSENGER VEHICLE,SMALL COM VEH(4 TIRES) 
861,2014-07-01,12:23:00,10473,40.8114146,-73.8561326,Cell Phone (hand-held),Unspecified,MOTORCYCLE,PASSENGER VEHICLE
862,2014-07-02,14:30:00,,,,Cell Phone (hands-free),,SPORT UTILITY / STATION WAGON,
863,2014-07-26,02:30:00,11365,40.7369217,-73.8085716,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
864,2014-07-04,19:25:00,11211,40.7167266,-73.9589122,Driver Inattention/Distraction,Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
865,2014-06-07,17:55:00,,40.753791,-73.7442778,Cell Phone (hands-free),Alcohol Involvement,PASSENGER VEHICLE,UNKNOWN
866,2014-06-14,00:30:00,10460,40.8439096,-73.8804621,Other Vehicular,Cell Phone (hands-free),SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
867,2014-06-10,09:10:00,10013,40.7193963,-74.0018831,Cell Phone (hand-held),Unspecified,SPORT UTILITY / STATION WAGON,SMALL COM VEH(4 TIRES) 
868,2014-06-17,19:13:00,11355,40.7461395,-73.8141606,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
869,2014-06-15,19:30:00,11236,40.6315501,-73.9063212,Cell Phone (hands-free),Unspecified,VAN,PASSENGER VEHICLE
870,2014-06-15,10:44:00,11220,40.6420578,-74.02042,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
871,2014-06-09,11:40:00,10024,40.7794786,-73.9735729,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
872,2014-06-22,17:20:00,,,,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
873,2014-05-21,10:40:00,11201,40.6976294,-73.9852826,Lost Consciousness,Cell Phone (hand-held),PASSENGER VEHICLE,VAN
874,2014-05-30,12:30:00,10028,40.7736554,-73.9517248,Cell Phone (hands-free),Unspecified,SMALL COM VEH(4 TIRES) ,SMALL COM VEH(4 TIRES) 
875,2014-05-17,22:35:00,,,,Cell Phone (hand-held),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
876,2014-05-07,13:37:00,10027,40.8077723,-73.9454833,Cell Phone (hands-free),,BUS,TAXI
877,2014-05-05,18:40:00,11362,40.7608547,-73.7229334,Lost Consciousness,Cell Phone (hand-held),SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
878,2014-05-04,04:33:00,10022,40.7606005,-73.9643142,Cell Phone (hands-free),Other Vehicular,PASSENGER VEHICLE,TAXI
879,2014-04-26,02:00:00,11208,40.6852702,-73.8665979,Cell Phone (hands-free),Other Vehicular,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
880,2014-05-02,14:15:00,10016,40.7452427,-73.9847921,Cell Phone (hands-free),Lost Consciousness,SMALL COM VEH(4 TIRES) ,SMALL COM VEH(4 TIRES) 
881,2014-04-28,14:30:00,10036,40.760405,-73.9874743,Cell Phone (hand-held),Fatigued/Drowsy,PASSENGER VEHICLE,VAN
882,2014-04-07,16:00:00,,,,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
883,2014-04-12,10:00:00,10001,40.7472362,-73.9933594,Cell Phone (hands-free),Fatigued/Drowsy,TAXI,TAXI
884,2014-04-27,19:30:00,,,,Cell Phone (hands-free),Backing Unsafely,PASSENGER VEHICLE,PASSENGER VEHICLE
885,2014-04-28,09:10:00,10013,40.7182736,-74.0053246,Cell Phone (hand-held),,SMALL COM VEH(4 TIRES) ,SPORT UTILITY / STATION WAGON
886,2014-04-16,18:15:00,,40.6956732,-73.9982301,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
887,2014-05-02,17:32:00,10017,40.7541542,-73.9803938,Cell Phone (hands-free),Unspecified,TAXI,BUS
888,2014-04-19,20:14:00,10038,40.7098718,-74.0070517,Cell Phone (hands-free),Cell Phone (hands-free),TAXI,SPORT UTILITY / STATION WAGON
889,2014-03-31,13:40:00,11218,40.6355523,-73.9780219,Cell Phone (hands-free),,SPORT UTILITY / STATION WAGON,OTHER
890,2014-04-03,17:20:00,11213,40.6687847,-73.9478174,Cell Phone (hand-held),Turning Improperly,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
891,2014-03-21,14:15:00,11201,40.7020602,-73.9926138,Cell Phone (hands-free),,PASSENGER VEHICLE,PASSENGER VEHICLE
892,2014-03-08,10:42:00,10016,40.7477733,-73.9850441,Cell Phone (hands-free),Outside Car Distraction,PASSENGER VEHICLE,PASSENGER VEHICLE
893,2014-03-30,04:09:00,,40.6673505,-73.7699326,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
894,2014-02-09,05:15:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
895,2014-03-06,19:10:00,10468,40.8646754,-73.8968314,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
896,2014-03-03,10:15:00,10007,40.7125314,-74.0076652,Driver Inattention/Distraction,Cell Phone (hand-held),PICK-UP TRUCK,TAXI
897,2014-02-04,11:47:00,10462,40.8362649,-73.8473152,Cell Phone (hands-free),Unspecified,SMALL COM VEH(4 TIRES) ,PASSENGER VEHICLE
898,2014-01-14,09:15:00,10035,40.8012913,-73.9438957,Cell Phone (hands-free),Unspecified,UNKNOWN,PASSENGER VEHICLE
899,2014-01-21,17:47:00,11369,40.7688406,-73.8696616,Cell Phone (hands-free),Pavement Slippery,PASSENGER VEHICLE,PASSENGER VEHICLE
900,2014-01-09,17:22:00,,,,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,TAXI
901,2014-01-27,16:35:00,11354,40.7629537,-73.8319573,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,TAXI
902,2014-01-15,18:00:00,11209,40.617583,-74.0304837,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
903,2014-01-31,16:05:00,10013,40.7203761,-74.0032612,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SMALL COM VEH(4 TIRES) 
904,2013-12-11,16:30:00,11421,40.6959506,-73.8623681,Cell Phone (hands-free),Driver Inattention/Distraction,PASSENGER VEHICLE,PASSENGER VEHICLE
905,2013-12-05,13:10:00,,,,Cell Phone (hand-held),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
906,2013-12-09,18:20:00,11362,40.7585123,-73.7224631,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
907,2013-12-28,19:19:00,10310,40.6347206,-74.1089308,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
908,2013-12-17,00:55:00,11206,40.7001078,-73.9538193,Cell Phone (hands-free),Cell Phone (hands-free),PASSENGER VEHICLE,PASSENGER VEHICLE
909,2013-12-16,02:30:00,,,,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
910,2013-12-29,17:00:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
911,2013-11-08,17:04:00,10014,40.7317832,-74.0065957,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,BICYCLE
912,2013-11-25,16:00:00,10011,40.7482105,-74.0074852,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,BUS
913,2013-12-05,20:00:00,,40.8040684,-73.9311544,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
914,2013-11-19,05:00:00,10016,40.7403604,-73.973177,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PICK-UP TRUCK
915,2013-11-27,13:35:00,11385,40.7096821,-73.8989037,Driver Inattention/Distraction,Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
916,2013-11-30,18:15:00,,,,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
917,2013-11-16,21:10:00,11210,40.6257308,-73.9563925,Cell Phone (hand-held),,PASSENGER VEHICLE,
918,2013-11-26,20:28:00,10016,40.7439442,-73.9836267,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
919,2013-10-16,04:00:00,11364,40.7362694,-73.7728608,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
920,2013-11-07,20:10:00,11373,40.7372527,-73.8660933,Cell Phone (hands-free),Cell Phone (hands-free),PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
921,2013-08-12,04:58:00,,,,Cell Phone (hands-free),,PASSENGER VEHICLE,
922,2013-10-22,23:32:00,11212,40.6624125,-73.909857,Cell Phone (hands-free),Physical Disability,VAN,PASSENGER VEHICLE
923,2013-10-31,13:00:00,11691,40.6072019,-73.7544356,Cell Phone (hand-held),Fatigued/Drowsy,BUS,SPORT UTILITY / STATION WAGON
924,2013-10-16,20:25:00,11373,40.7394262,-73.8807867,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,BICYCLE
925,2013-11-02,13:30:00,11368,40.7571324,-73.8704137,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
926,2013-10-31,22:45:00,10036,40.7633754,-73.9964587,Cell Phone (hands-free),Lost Consciousness,PASSENGER VEHICLE,PASSENGER VEHICLE
927,2013-11-02,12:20:00,,40.6051344,-74.0723541,Cell Phone (hand-held),Backing Unsafely,PASSENGER VEHICLE,VAN
928,2013-10-18,07:45:00,11230,40.6146211,-73.9686568,Driver Inattention/Distraction,Cell Phone (hands-free),SPORT UTILITY / STATION WAGON,BICYCLE
929,2013-10-19,14:25:00,11249,40.7208456,-73.9566297,Cell Phone (hand-held),Backing Unsafely,SPORT UTILITY / STATION WAGON,OTHER
930,2013-10-29,13:00:00,,,,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,BICYCLE
931,2013-09-15,19:55:00,11691,40.5997284,-73.763869,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,OTHER
932,2013-10-02,16:00:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
933,2013-10-07,20:40:00,10472,40.8260286,-73.8785792,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
934,2013-09-11,19:44:00,11238,40.6783423,-73.9551972,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,LIVERY VEHICLE
935,2013-09-29,01:00:00,10028,40.7736554,-73.9517248,Cell Phone (hands-free),Other Vehicular,PASSENGER VEHICLE,PASSENGER VEHICLE
936,2013-09-12,17:54:00,,,,Cell Phone (hands-free),Cell Phone (hands-free),SPORT UTILITY / STATION WAGON,VAN
937,2013-10-03,00:53:00,10472,40.8299794,-73.8823806,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
938,2013-09-20,16:53:00,,,,Cell Phone (hand-held),Fatigued/Drowsy,PASSENGER VEHICLE,LARGE COM VEH(6 OR MORE TIRES)
939,2013-09-21,00:46:00,10002,40.7156221,-73.9942752,Cell Phone (hands-free),Unspecified,MOTORCYCLE,PASSENGER VEHICLE
940,2013-08-23,17:15:00,,40.6663873,-73.8017668,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
941,2013-08-22,17:45:00,,40.767373,-73.9500574,Other Vehicular,Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
942,2013-08-25,21:05:00,11416,40.6806304,-73.8587871,Driver Inattention/Distraction,Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
943,2013-08-13,00:20:00,11367,40.7245944,-73.8184129,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
944,2013-08-20,09:50:00,11207,40.6759124,-73.8949099,Cell Phone (hands-free),Unspecified,LARGE COM VEH(6 OR MORE TIRES),PASSENGER VEHICLE
945,2013-08-24,01:00:00,10452,40.8336278,-73.9261433,Cell Phone (hands-free),Other Vehicular,PASSENGER VEHICLE,PASSENGER VEHICLE
946,2013-08-20,23:45:00,10012,40.7203211,-73.9940403,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
947,2013-08-25,03:50:00,11209,40.6314641,-74.0277916,Other Electronic Device,Cell Phone (hands-free),PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
948,2013-08-07,01:22:00,,40.8965978,-73.8607981,Cell Phone (hands-free),,MOTORCYCLE,
949,2013-08-09,14:00:00,11216,40.682537,-73.9500096,Cell Phone (hand-held),Unspecified,VAN,SPORT UTILITY / STATION WAGON
950,2013-07-13,01:25:00,10459,40.820189,-73.8906752,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
951,2013-07-25,10:36:00,10024,40.7845371,-73.9735961,Cell Phone (hand-held),Unspecified,VAN,SPORT UTILITY / STATION WAGON
952,2013-07-19,13:50:00,,,,Cell Phone (hand-held),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
953,2013-07-15,19:00:00,11206,40.7070523,-73.9320869,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,UNKNOWN
954,2013-06-21,15:45:00,10013,40.7206286,-74.0052093,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
955,2013-06-12,05:07:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
956,2013-05-24,18:32:00,11420,40.6654902,-73.8195255,Cell Phone (hands-free),,VAN,OTHER
957,2013-05-31,07:30:00,11201,40.7006626,-73.9877415,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
958,2013-05-15,13:32:00,,40.7487374,-73.7583771,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
959,2013-05-14,18:24:00,,,,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
960,2013-04-27,16:10:00,11365,40.7419329,-73.7969515,Cell Phone (hands-free),,PASSENGER VEHICLE,PASSENGER VEHICLE
961,2013-05-05,20:35:00,11228,40.607148,-74.0115678,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
962,2013-05-07,07:40:00,11379,40.7124548,-73.8820542,Failure to Yield Right-of-Way,Cell Phone (hands-free),PASSENGER VEHICLE,PASSENGER VEHICLE
963,2013-04-22,15:45:00,11226,40.6526435,-73.9497689,Cell Phone (hands-free),Cell Phone (hands-free),PASSENGER VEHICLE,PASSENGER VEHICLE
964,2013-04-26,13:40:00,11232,40.6571092,-74.0015101,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
965,2013-03-23,15:38:00,10024,40.7890514,-73.9703009,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PICK-UP TRUCK
966,2013-03-17,19:26:00,10457,40.8435983,-73.90586,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,UNKNOWN
967,2013-04-12,15:30:00,10007,40.7130557,-74.0072251,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
968,2013-04-10,16:38:00,10013,40.7170768,-74.006248,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,MOTORCYCLE
969,2013-04-08,01:44:00,,40.6649325,-73.8019481,Cell Phone (hands-free),Unspecified,TAXI,PASSENGER VEHICLE
970,2013-04-07,17:29:00,10027,40.8077723,-73.9454833,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
971,2013-03-17,08:30:00,10452,40.8392249,-73.9150891,Cell Phone (hand-held),Backing Unsafely,PASSENGER VEHICLE,PASSENGER VEHICLE
972,2013-04-08,17:05:00,11101,40.7446585,-73.9485231,Cell Phone (hand-held),Unspecified,TAXI,PASSENGER VEHICLE
973,2013-03-16,16:35:00,10018,40.7564889,-73.9977585,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,UNKNOWN
974,2013-02-16,19:23:00,10472,40.8316236,-73.8672585,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
975,2013-02-11,18:15:00,,40.6006911,-74.0100458,Cell Phone (hands-free),,LARGE COM VEH(6 OR MORE TIRES),
976,2013-01-18,17:45:00,11225,40.6631828,-73.9624487,Failure to Yield Right-of-Way,Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
977,2013-02-07,06:20:00,10306,40.5550339,-74.1297557,Cell Phone (hands-free),,PASSENGER VEHICLE,
978,2013-02-01,14:28:00,,40.7263443,-73.7650719,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
979,2012-12-20,08:30:00,,,,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
980,2012-12-23,23:15:00,,,,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
981,2013-01-10,04:42:00,11208,40.6657345,-73.8656926,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,AMBULANCE
982,2012-12-14,16:00:00,,40.6037297,-74.1862851,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
983,2012-12-30,13:29:00,11201,40.696197,-73.9887629,Cell Phone (hands-free),Fatigued/Drowsy,PASSENGER VEHICLE,PASSENGER VEHICLE
984,2012-12-19,18:20:00,11222,40.7263019,-73.9491181,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
985,2012-12-07,14:10:00,11219,40.636147,-73.9909565,Cell Phone (hands-free),Unspecified,SMALL COM VEH(4 TIRES) ,PASSENGER VEHICLE
986,2012-11-22,22:25:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
987,2012-11-20,18:15:00,11229,40.616045,-73.9448294,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,VAN
988,2012-12-03,22:15:00,10018,40.7571064,-73.9973001,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
989,2012-11-25,20:30:00,10075,40.7742786,-73.959393,Other Vehicular,Cell Phone (hand-held),PASSENGER VEHICLE,TAXI
990,2012-11-13,00:30:00,11205,40.6980388,-73.9628402,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
991,2012-11-22,16:41:00,,,,Cell Phone (hands-free),Cell Phone (hands-free),PASSENGER VEHICLE,PASSENGER VEHICLE
992,2012-11-30,15:20:00,10128,40.7872263,-73.9541633,Cell Phone (hands-free),Unspecified,BUS,PASSENGER VEHICLE
993,2012-12-02,11:57:00,,,,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
994,2012-11-24,03:00:00,,40.8744985,-73.9276086,Cell Phone (hand-held),,SPORT UTILITY / STATION WAGON,
995,2012-10-17,13:02:00,10027,40.8155447,-73.9569184,Cell Phone (hands-free),,PICK-UP TRUCK,
996,2012-10-30,14:45:00,10468,40.8713965,-73.8930715,Cell Phone (hands-free),,PASSENGER VEHICLE,
997,2012-10-18,20:30:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
998,2012-10-25,21:30:00,11229,40.5961594,-73.9520188,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
999,2012-10-14,13:24:00,11419,40.6946808,-73.8142752,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
1000,2012-09-17,17:30:00,11235,40.5875431,-73.958196,Driver Inattention/Distraction,Cell Phone (hands-free),PICK-UP TRUCK,PASSENGER VEHICLE
1001,2012-09-23,14:22:00,11222,40.7265374,-73.9543927,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,UNKNOWN
1002,2012-09-21,10:00:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
1003,2012-09-19,08:35:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
1004,2012-09-23,19:51:00,,,,Backing Unsafely,Cell Phone (hands-free),SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
1005,2012-09-30,01:40:00,,40.6519753,-73.8654089,Cell Phone (hand-held),,SPORT UTILITY / STATION WAGON,
1006,2012-10-06,17:40:00,11422,40.6663969,-73.7385662,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
1007,2012-09-18,11:30:00,,,,Physical Disability,Cell Phone (hand-held),PASSENGER VEHICLE,PASSENGER VEHICLE
1008,2012-08-19,20:44:00,10314,40.6159939,-74.1636026,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,SPORT UTILITY / STATION WAGON
1009,2012-09-02,12:00:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,SPORT UTILITY / STATION WAGON
1010,2012-09-06,04:31:00,11373,40.7465711,-73.8837441,Cell Phone (hand-held),,PASSENGER VEHICLE,
1011,2012-09-08,00:40:00,11201,40.6960346,-73.9845292,Cell Phone (hands-free),Unspecified,UNKNOWN,UNKNOWN
1012,2012-08-24,18:11:00,10014,40.7286048,-74.0053146,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,TAXI
1013,2012-08-02,23:10:00,,40.7446461,-73.7703999,Cell Phone (hand-held),Unspecified,SPORT UTILITY / STATION WAGON,UNKNOWN
1014,2012-07-12,11:15:00,10012,40.7296864,-73.9986037,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,UNKNOWN
1015,2012-07-31,09:38:00,10023,40.7697419,-73.9821185,Cell Phone (hands-free),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
1016,2012-07-14,20:20:00,10305,40.598935,-74.0637592,Physical Disability,Cell Phone (hands-free),SMALL COM VEH(4 TIRES) ,VAN
1017,2012-07-15,21:15:00,10019,40.7691169,-73.9885593,Cell Phone (hand-held),Unspecified,PASSENGER VEHICLE,PASSENGER VEHICLE
1018,2012-07-01,01:03:00,,,,Cell Phone (hands-free),Unspecified,SPORT UTILITY / STATION WAGON,PASSENGER VEHICLE
1019,2012-07-03,21:48:00,11692,40.5901644,-73.7978594,Cell Phone (hands-free),,PASSENGER VEHICLE,
1020,2024-07-12,18:49:00,10035,40.80711,-73.93753,Cell Phone (hand-Held),Unspecified,Sedan,Bike
1021,2024-12-31,22:01:00,10467,40.858074,-73.86788,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
1022,2024-11-18,06:00:00,,,,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
1023,2024-07-27,00:00:00,,,,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
1024,2025-01-15,15:20:00,,40.882393,-73.83622,Cell Phone (hands-free),Unspecified,Sedan,Bike
1025,2024-08-12,18:25:00,,40.85638,-73.82631,Cell Phone (hand-Held),Unsafe Lane Changing,Sedan,
1026,2024-08-28,18:15:00,,,,Cell Phone (hands-free),Unspecified,Sedan,subn
1027,2024-09-12,20:00:00,,,,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
1028,2024-10-03,15:02:00,,40.61821,-73.89728,Cell Phone (hand-Held),Following Too Closely,Sedan,Station Wagon/Sport Utility Vehicle
1029,2024-07-23,11:40:00,10465,40.82553,-73.82309,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
1030,2024-09-03,04:36:00,11432,40.705784,-73.805824,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
1031,2024-08-10,00:00:00,11212,40.667213,-73.90975,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
1032,2024-08-02,04:15:00,10036,40.75668,-73.980606,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Bike
1033,2024-09-12,15:20:00,11215,40.671314,-73.99448,Cell Phone (hand-Held),Unspecified,Sedan,Bike
1034,2024-09-25,19:05:00,11201,40.690483,-73.99636,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
1035,2024-10-05,17:38:00,10013,,,Cell Phone (hands-free),,Bike,
1036,2024-11-04,22:36:00,11105,40.77652,-73.91592,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
1037,2024-11-15,01:58:00,11419,40.691643,-73.81119,Cell Phone (hands-free),Unspecified,Station Wagon/Sport Utility Vehicle,Taxi
1038,2024-11-05,12:10:00,10454,40.810387,-73.9152,Cell Phone (hand-Held),,,
1039,2024-12-06,15:30:00,,40.800983,-73.92927,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
1040,2024-12-10,14:55:00,,40.64254,-73.87652,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
1041,2024-12-13,23:23:00,11358,40.76044,-73.80492,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
1042,2024-12-12,23:30:00,11364,40.749794,-73.753784,Traffic Control Disregarded,Cell Phone (hand-Held),Sedan,Sedan
1043,2025-02-01,20:30:00,11203,40.655155,-73.93368,Cell Phone (hand-Held),Unspecified,Sedan,Van
1044,2025-02-02,11:42:00,10461,40.84938,-73.85382,Cell Phone (hand-Held),Other Vehicular,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
1045,2025-01-19,19:27:00,11693,40.590786,-73.80662,Cell Phone (hands-free),,Station Wagon/Sport Utility Vehicle,
1046,2025-02-03,10:40:00,10310,40.64513,-74.10872,Cell Phone (hand-Held),Unspecified,Bus,Sedan
1047,2025-02-07,13:39:00,11370,40.77064,-73.898094,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
1048,2025-02-13,23:20:00,,40.637188,-73.8792,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
1049,2025-02-16,21:30:00,10034,40.8658,-73.92,Passing or Lane Usage Improper,Cell Phone (hand-Held),Sedan,
1050,2025-02-21,21:19:00,10027,40.809357,-73.94963,Driver Inattention/Distraction,Cell Phone (hands-free),Pick-up Truck,Sedan
1051,2025-03-01,11:21:00,10029,40.789684,-73.94814,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
1052,2025-03-02,15:52:00,10027,40.812252,-73.962105,Reaction to Uninvolved Vehicle,Cell Phone (hand-Held),Sedan,Sedan
1053,2025-03-05,17:03:00,,40.840767,-73.9173,Driver Inattention/Distraction,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Bike
1054,2025-03-10,23:59:00,11201,40.689857,-73.99841,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
1055,2025-03-12,12:31:00,,40.741806,-73.8463,Cell Phone (hand-Held),,Station Wagon/Sport Utility Vehicle,
1056,2025-03-14,12:49:00,11693,40.590504,-73.812454,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
1057,2025-03-15,01:10:00,11368,40.737713,-73.85973,Cell Phone (hand-Held),Other Vehicular,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
1058,2025-03-27,10:50:00,,40.845806,-73.92921,Other Vehicular,Cell Phone (hand-Held),Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
1059,2025-04-08,08:15:00,10030,40.822838,-73.94192,Cell Phone (hand-Held),,Sedan,
1060,2025-04-03,06:30:00,10455,40.812313,-73.91647,Cell Phone (hand-Held),Unspecified,Sedan,Station Wagon/Sport Utility Vehicle
1061,2025-04-19,16:35:00,11103,40.765675,-73.91112,Cell Phone (hand-Held),Unspecified,Sedan,Sedan
1062,2025-04-28,15:29:00,10469,40.86229,-73.8471,Cell Phone (hand-Held),Unspecified,Sedan,Bike
1063,2025-05-01,17:17:00,11203,40.662575,-73.93447,Cell Phone (hand-Held),,Sedan,
1064,2025-05-14,00:12:00,11235,40.58163,-73.96238,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Station Wagon/Sport Utility Vehicle
1065,2025-05-24,00:26:00,11423,40.709423,-73.77544,Cell Phone (hand-Held),Unspecified,Station Wagon/Sport Utility Vehicle,Sedan
