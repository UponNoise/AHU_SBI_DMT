#,factor,cnt,rnk
1,Driver Inattention/Distraction,4050,1
2,Failure to Yield Right-of-Way,1786,2
3,Following Too Closely,1084,3
4,Backing Unsafely,737,4
5,Passing Too Closely,698,5
6,Other Vehicular,648,6
7,Unsafe Speed,624,7
8,Traffic Control Disregarded,623,8
9,Passing or Lane Usage Improper,563,9
10,Turning Improperly,480,10
11,Unsafe Lane Changing,341,11
12,Driver Inexperience,320,12
13,Alcohol Involvement,291,13
14,View Obstructed/Limited,208,14
15,Pavement Slippery,202,15
16,Fatigued/Drowsy,200,16
17,Reaction to Uninvolved Vehicle,186,17
18,Aggressive Driving/Road Rage,137,18
19,Lost Consciousness,126,19
20,Oversized Vehicle,121,20
