-- topfactors.sql

WITH all_factors AS (
    SELECT contributing_factor_vehicle1 AS factor
    FROM collision
    WHERE contributing_factor_vehicle1 IS NOT NULL AND contributing_factor_vehicle1 != ''
    
    UNION ALL
    
    SELECT contributing_factor_vehicle2 AS factor
    FROM collision
    WHERE contributing_factor_vehicle2 IS NOT NULL AND contributing_factor_vehicle2 != ''
)

SELECT factor, COUNT(*) AS count
FROM all_factors
GROUP BY factor
ORDER BY count DESC
LIMIT 20;