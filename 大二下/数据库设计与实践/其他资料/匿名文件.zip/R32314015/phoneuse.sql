-- phoneuse.sql
SELECT *
FROM collision
WHERE contributing_factor_vehicle1 IN ('Cell Phone (hand-Held)', 'Cell Phone (hands-free)')
   OR contributing_factor_vehicle2 IN ('Cell Phone (hand-Held)', 'Cell Phone (hands-free)');
