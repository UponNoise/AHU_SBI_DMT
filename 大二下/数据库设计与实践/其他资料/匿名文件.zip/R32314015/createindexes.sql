-- createindexes.sql

CREATE INDEX idx_cf_vehicle1 ON collision (contributing_factor_vehicle1);
CREATE INDEX idx_cf_vehicle2 ON collision (contributing_factor_vehicle2);
CREATE INDEX idx_zipcode ON collision (zip_code);