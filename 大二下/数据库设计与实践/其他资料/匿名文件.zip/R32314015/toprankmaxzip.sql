-- toprankmaxzip.sql

WITH factor_counts AS (
    SELECT contributing_factor_vehicle1 AS factor, COUNT(*) AS cnt
    FROM collision
    WHERE zip_code = '11207'
      AND contributing_factor_vehicle1 IS NOT NULL
      AND contributing_factor_vehicle1 NOT IN ('', 'Unspecified')
    GROUP BY contributing_factor_vehicle1
),
ranked_factors AS (
    SELECT factor, cnt,
           RANK() OVER (ORDER BY cnt DESC) AS rnk
    FROM factor_counts
)

SELECT factor, cnt, rnk
FROM ranked_factors
WHERE rnk <= 20;