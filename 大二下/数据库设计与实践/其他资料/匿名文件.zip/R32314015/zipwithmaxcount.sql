-- zipwithmaxcount.sql

SELECT zip_code, COUNT(*) AS collision_count
FROM collision
WHERE zip_code IS NOT NULL
GROUP BY zip_code
ORDER BY collision_count DESC
LIMIT 1;