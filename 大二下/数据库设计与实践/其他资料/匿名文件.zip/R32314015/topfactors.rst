#,factor,count
1,Unspecified,2278476
2,Driver Inattention/Distraction,540458
3,Failure to Yield Right-of-Way,148417
4,Following Too Closely,137533
5,Other Vehicular,101386
6,Backing Unsafely,88023
7,Passing or Lane Usage Improper,75839
8,Passing Too Closely,64468
9,Turning Improperly,62766
10,Fatigued/Drowsy,58361
11,Unsafe Lane Changing,50013
12,Traffic Control Disregarded,47742
13,Driver Inexperience,41940
14,Unsafe Speed,38950
15,Alcohol Involvement,26512
16,Lost Consciousness,25969
17,Reaction to Uninvolved Vehicle,24795
18,Pavement Slippery,24755
19,Prescription Medication,18449
20,View Obstructed/Limited,18228
